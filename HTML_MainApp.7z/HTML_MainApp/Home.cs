﻿using HTML_MainApp.Classes;
using HTML_MainApp.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;

namespace HTML_MainApp
{
    public partial class Home : Form
    {

        public Home()
        {
            InitializeComponent();
        }



        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (cmbType.SelectedItem.ToString() == "Image")
            {
                AddImage add = new AddImage();
                add.ShowDialog();
                if (add != null && add.Adi != null)
                {
                    if (add.Adi.isSet)
                    {
                        AdiImage img = add.Adi;
                        AddRowInGrid(cmbType.SelectedItem.ToString(), "", img.background_color, img.imagePath, img.width, img.alignment, "-", img.alink, ConvertNullsToZero(img.pTop) + "," + ConvertNullsToZero(img.pBottom) + "," + ConvertNullsToZero(img.pLeft) + "," + ConvertNullsToZero(img.pRight),
                         ConvertNullsToZero(img.mTop) + "," + ConvertNullsToZero(img.mBottom) + "," + ConvertNullsToZero(img.mLeft) + "," + ConvertNullsToZero(img.mRight),
                         ConvertNullsToZero(img.bTop) + "," + ConvertNullsToZero(img.bBottom) + "," + ConvertNullsToZero(img.bLeft) + "," + ConvertNullsToZero(img.bRight),
                         img, null);
                    }
                    add.Close();
                    add.Dispose();
                    this.Focus();
                }
            }
            if (cmbType.SelectedItem.ToString() == "Text")
            {
                AddText add = new AddText();
                add.ShowDialog();
                if (add != null && add.Adi != null)
                {
                    if (add.Adi.isSet)
                    {
                        AdiText img = add.Adi;

                        StringBuilder font = new StringBuilder();
                        font.Append(img.fontProperties.font_family + "; " + img.fontProperties.font_size + "px; ");
                        if (img.fontProperties.bold) font.Append("bold; ");
                        if (img.fontProperties.italic) font.Append("italic; ");
                        if (img.fontProperties.underline) font.Append("underline; ");

                        AddRowInGrid(cmbType.SelectedItem.ToString(), "", img.fontProperties.background_color, "-", null, img.alignment, img.style, "img.alink", ConvertNullsToZero(img.fontProperties.pTop) + "," + ConvertNullsToZero(img.fontProperties.pBottom) + "," + ConvertNullsToZero(img.fontProperties.pLeft) + "," + ConvertNullsToZero(img.fontProperties.pRight),
                         ConvertNullsToZero(img.fontProperties.mTop) + "," + ConvertNullsToZero(img.fontProperties.mBottom) + "," + ConvertNullsToZero(img.fontProperties.mLeft) + "," + ConvertNullsToZero(img.fontProperties.mRight),
                         ConvertNullsToZero(img.fontProperties.bTop) + "," + ConvertNullsToZero(img.fontProperties.bBottom) + "," + ConvertNullsToZero(img.fontProperties.bLeft) + "," + ConvertNullsToZero(img.fontProperties.bRight),
                         img, img.text);
                        add.Close();
                        add.Dispose();
                        this.Focus();
                    }
                }
            }

            if (cmbType.SelectedItem.ToString() == "Spacer")
            {
                Add_Spacer add = new Add_Spacer();
                add.ShowDialog();
                if (add != null && add.spc != null)
                {
                    if (add.spc.isAdded)
                    {
                        AddRowInGrid(cmbType.SelectedItem.ToString(), "", add.spc.BgColor, add.spc.Link, add.spc.Height, null, null, null, null,
                        null, null, add.spc, null);
                        add.Close();
                        add.Dispose();
                        this.Focus();
                    }
                }
            }
            if (cmbType.SelectedItem.ToString() == "1Xi Text")
            {
                AddText_1xi add = new AddText_1xi();
                add.ShowDialog();
                if (add != null && add.Adi != null)
                {
                    if (add.IsAdded)
                    {
                        AddRowInGrid(cmbType.SelectedItem.ToString(), "", null, null, null, null, null, null, null,
                        null, null, add.Adi, null);
                        add.Close();
                        add.Dispose();
                        this.Focus();
                    }
                }
            }

            if (cmbType.SelectedItem.ToString() == "1Xi Image")
            {
                AddImage_1xi add = new AddImage_1xi();
                add.ShowDialog();
                if (add != null && add.Adi != null)
                {
                    if (add.IsAdded)
                    {
                        AddRowInGrid(cmbType.SelectedItem.ToString(), "", null, null, null, null, null, null, null,
                        null, null, add.Adi, null);
                        add.Close();
                        add.Dispose();
                        this.Focus();
                    }
                }
            }

        }

        private int ConvertNullsToZero(int? value)
        {
            if (value != null)
            {
                return (int)value;
            }
            else return 0;
        }

        private void AddRowInGrid(string type, string Class, string BgColor, string path, int? width, string alignment, string font, string link, string padding, string margin, string border, object Object, string text)
        {

            this.dgvStructure.Rows.Add(type, Class, BgColor, path, text, width, alignment, font, link, padding, margin, border, Object);
        }


        private void moveUp()
        {
            if (dgvStructure.RowCount > 0)
            {
                if (dgvStructure.SelectedRows.Count > 0)
                {
                    int rowCount = dgvStructure.Rows.Count;
                    int index = dgvStructure.SelectedCells[0].OwningRow.Index;

                    if (index == 0)
                    {
                        return;
                    }
                    DataGridViewRowCollection rows = dgvStructure.Rows;

                    // remove the previous row and add it behind the selected row.
                    DataGridViewRow prevRow = rows[index - 1];
                    rows.Remove(prevRow);
                    prevRow.Frozen = false;
                    rows.Insert(index, prevRow);
                    dgvStructure.ClearSelection();
                    dgvStructure.Rows[index - 1].Selected = true;
                }
            }
        }

        private void moveDown()
        {
            if (dgvStructure.RowCount > 0)
            {
                if (dgvStructure.SelectedRows.Count > 0)
                {
                    int rowCount = dgvStructure.Rows.Count;
                    int index = dgvStructure.SelectedCells[0].OwningRow.Index;

                    if (index == (rowCount - 2)) // include the header row
                    {
                        return;
                    }
                    DataGridViewRowCollection rows = dgvStructure.Rows;

                    // remove the next row and add it in front of the selected row.
                    DataGridViewRow nextRow = rows[index + 1];
                    rows.Remove(nextRow);
                    nextRow.Frozen = false;
                    rows.Insert(index, nextRow);
                    dgvStructure.ClearSelection();
                    dgvStructure.Rows[index + 1].Selected = true;
                }
            }
        }

        #region Move

        private void btnUp_Click(object sender, EventArgs e)
        {
            moveUp();
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            moveDown();
        }

        #endregion Move



        public string ToXml(DataSet ds)
        {
            using (var memoryStream = new MemoryStream())
            {
                using (TextWriter streamWriter = new StreamWriter(memoryStream))
                {
                    var xmlSerializer = new XmlSerializer(typeof(DataSet));
                    xmlSerializer.Serialize(streamWriter, ds);
                    return Encoding.UTF8.GetString(memoryStream.ToArray());
                }
            }
        }



        private void dgvStructure_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewRow row = dgvStructure.Rows[e.RowIndex];
            if (row != null && row.Cells["Type"] != null && row.Cells["Type"].Value != null)
            {
                string type = row.Cells["Type"].Value.ToString();
                if (type == "Image")
                {
                    AddImage add = new AddImage((AdiImage)row.Cells["Object"].Value);
                    //dgvStructure.Rows.Remove(row);
                    add.ShowDialog();
                    if (add != null && add.Adi != null)
                    {
                        if (add.Adi.isUpdated)
                        {
                            AdiImage img = add.Adi;
                            row.Cells["BgColor"].Value = img.background_color;
                            row.Cells["Path"].Value = img.imagePath;
                            row.Cells["Width"].Value = img.width;
                            row.Cells["Alignment"].Value = img.alignment;
                            row.Cells["Link"].Value = img.alink;
                            row.Cells["Padding"].Value = ConvertNullsToZero(img.pTop) + "," + ConvertNullsToZero(img.pBottom) + "," + ConvertNullsToZero(img.pLeft) + "," + ConvertNullsToZero(img.pRight);
                            row.Cells["Margin"].Value = ConvertNullsToZero(img.mTop) + "," + ConvertNullsToZero(img.mBottom) + "," + ConvertNullsToZero(img.mLeft) + "," + ConvertNullsToZero(img.mRight);
                            row.Cells["Border"].Value = ConvertNullsToZero(img.bTop) + "," + ConvertNullsToZero(img.bBottom) + "," + ConvertNullsToZero(img.bLeft) + "," + ConvertNullsToZero(img.bRight);
                            row.Cells["Object"].Value = img;

                            add.Close();
                            add.Dispose();
                            this.Focus();
                        }

                    }
                }

                if (type == "Text")
                {
                    AddText add = new AddText((AdiText)row.Cells["Object"].Value);

                    add.ShowDialog();
                    if (add != null && add.Adi != null)
                    {
                        if (add.Adi.isUpdated)
                        {

                            AdiText img = add.Adi;
                            FontProperties prop = add.Adi.fontProperties;
                            row.Cells["BgColor"].Value = prop.background_color;
                            row.Cells["Alignment"].Value = img.alignment;
                            row.Cells["Font"].Value = img.style;
                            //row.Cells["Link"].Value = img.alink;
                            row.Cells["Padding"].Value = ConvertNullsToZero(prop.pTop) + "," + ConvertNullsToZero(prop.pBottom) + "," + ConvertNullsToZero(prop.pLeft) + "," + ConvertNullsToZero(prop.pRight);
                            row.Cells["Margin"].Value = ConvertNullsToZero(prop.mTop) + "," + ConvertNullsToZero(prop.mBottom) + "," + ConvertNullsToZero(prop.mLeft) + "," + ConvertNullsToZero(prop.mRight);
                            row.Cells["Border"].Value = ConvertNullsToZero(prop.bTop) + "," + ConvertNullsToZero(prop.bBottom) + "," + ConvertNullsToZero(prop.bLeft) + "," + ConvertNullsToZero(prop.bRight);
                            row.Cells["Object"].Value = img;
                            row.Cells["Text"].Value = img.text;
                            add.Close();
                            add.Dispose();
                            this.Focus();
                        }
                    }
                }
                if (type == "Spacer")
                {
                    Add_Spacer add = new Add_Spacer((AdiSpacer)row.Cells["Object"].Value);
                    add.ShowDialog();
                    if (add != null && add.spc != null)
                    {
                        if (add.spc.isUpdated)
                        {
                            //+ img.fontProperties.bold ? "bold; " : null +""+ img.fontProperties.italic ? "italic; " : null + "" + img.fontProperties.underline ? "underline; " : null;

                            row.Cells["BgColor"].Value = add.spc.BgColor;
                            row.Cells["Width"].Value = add.spc.Height;
                            row.Cells["Path"].Value = add.spc.Link;
                            row.Cells["Object"].Value = add.spc;

                            add.Close();
                            add.Dispose();
                            this.Focus();
                        }
                    }
                }

                if (type == "1Xi Text")
                {
                    AddText_1xi add = new AddText_1xi((AdiText_1xi)row.Cells["Object"].Value);
                    add.ShowDialog();
                    if (add != null && add.Adi != null)
                    {
                        // if (add.spc.isUpdated)
                        {
                            //+ img.fontProperties.bold ? "bold; " : null +""+ img.fontProperties.italic ? "italic; " : null + "" + img.fontProperties.underline ? "underline; " : null;

                            //row.Cells["BgColor"].Value = add.spc.BgColor;
                            //row.Cells["Width"].Value = add.spc.Height;
                            //row.Cells["Path"].Value = add.spc.Link;
                            row.Cells["Object"].Value = add.Adi;

                            add.Close();
                            add.Dispose();
                            this.Focus();
                        }
                    }
                }

                if (type == "1Xi Image")
                {
                    AddImage_1xi add = new AddImage_1xi((AdiImage_1xi)row.Cells["Object"].Value);
                    add.ShowDialog();
                    if (add != null && add.Adi != null)
                    {
                        // if (add.spc.isUpdated)
                        {
                            //+ img.fontProperties.bold ? "bold; " : null +""+ img.fontProperties.italic ? "italic; " : null + "" + img.fontProperties.underline ? "underline; " : null;

                            //row.Cells["BgColor"].Value = add.spc.BgColor;
                            //row.Cells["Width"].Value = add.spc.Height;
                            //row.Cells["Path"].Value = add.spc.Link;
                            row.Cells["Object"].Value = add.Adi;

                            add.Close();
                            add.Dispose();
                            this.Focus();
                        }
                    }
                }
                //if (type == "1Xi Text")
                //{
                //    AddText_1xi add = new AddText_1xi((AdiText_1xi)row.Cells["Object"].Value);
                //    add.ShowDialog();
                //    if (add != null && add.spc != null)
                //    {
                //        if (add.spc.isUpdated)
                //        {
                //            //+ img.fontProperties.bold ? "bold; " : null +""+ img.fontProperties.italic ? "italic; " : null + "" + img.fontProperties.underline ? "underline; " : null;

                //            row.Cells["BgColor"].Value = add.spc.BgColor;
                //            row.Cells["Width"].Value = add.spc.Height;
                //            row.Cells["Path"].Value = add.spc.Link;


                //            add.Close();
                //            add.Dispose();
                //            this.Focus();
                //        }
                //    }
                //}

            }
        }


        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            // Get file name.
            var cntrl = sender as SaveFileDialog;

            string name = cntrl.FileName;

            DataTable dt = new DataTable();

            dt.TableName = "MyTable";
            foreach (DataGridViewColumn col in dgvStructure.Columns)
            {
                if (col.HeaderText == "Object")
                {
                    dt.Columns.Add(col.HeaderText, typeof(object));
                }
                else
                {
                    dt.Columns.Add(col.HeaderText);
                }
            }

            foreach (DataGridViewRow row in dgvStructure.Rows)
            {
                DataRow dRow = dt.NewRow();
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null && cell.Value.GetType() == typeof(HTML_MainApp.Classes.AdiImage))
                    {
                        AdiImage add = (AdiImage)cell.Value;

                        dRow[cell.ColumnIndex] = add;
                    }
                    else if (cell.Value != null && cell.Value.GetType() == typeof(HTML_MainApp.Classes.AdiText))
                    {
                        AdiText add = (AdiText)cell.Value;

                        dRow[cell.ColumnIndex] = add;
                    }
                    else if (cell.Value != null && cell.Value.GetType() == typeof(HTML_MainApp.Classes.AdiSpacer))
                    {
                        AdiSpacer add = (AdiSpacer)cell.Value;

                        dRow[cell.ColumnIndex] = add;
                    }


                    else
                        dRow[cell.ColumnIndex] = cell.Value;
                }
                dt.Rows.Add(dRow);
            }

            dt.WriteXml(name);

            MessageBox.Show("Data Exported");


        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {

            SaveFileDialog s = new SaveFileDialog();
            s.FileOk += saveFileDialog1_FileOk;
            s.DefaultExt = "txt";
            s.Filter = "Text File|*.xml";
            s.ShowDialog();

        }


        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataTable table = new DataTable("MyTable");
            try
            {
                OpenFileDialog o = new OpenFileDialog();
                o.Filter = "XML Files|*.xml";
                o.Multiselect = false;
                DialogResult result = o.ShowDialog();
                if (result == DialogResult.OK) // Test result.
                {
                    using (Stream stream = new FileStream(o.FileName, FileMode.Open, FileAccess.Read))
                    {

                        foreach (DataGridViewColumn col in dgvStructure.Columns)
                        {
                            if (col.HeaderText == "Object")
                            {
                                table.Columns.Add(col.HeaderText, typeof(object));
                            }
                            else
                            {
                                table.Columns.Add(col.HeaderText);
                            }
                        }

                        table.ReadXml(stream);
                        dgvStructure.Columns.Clear();
                        if (dgvStructure.Rows != null && dgvStructure.Rows.Count != 0) dgvStructure.Rows.Clear();

                        dgvStructure.DataSource = table;

                    }


                }
            }
            catch (Exception ex)
            {
                // return table;
            }

        }

        private void btnCreateHTML_Click(object sender, EventArgs e)
        {
            List<object> list = new List<object>();

            foreach (DataGridViewRow row in dgvStructure.Rows)
            {
                if (row.Cells["Type"].Value.ToString() == "Image")
                {
                    AdiImage img = (AdiImage)row.Cells["Object"].Value;
                    img.HTML = String.Format(@"      <tr>
            <td>
                <table cellpadding=""0"" cellspacing=""0"" border=""0"" width=""100%"">
                    <!-- body part 1 starts -->
                    <tr>
                        <td>
                            <table border=""0"" cellpadding=""0"" cellspacing=""0"" width=""100%"">
                                <tr>
                                    <td align=""center"" valign=""top"" style=""background-color:#{0};"">
                                        <table border=""0"" width=""640"" cellpadding=""0"" cellspacing=""0"" class=""container"" style=""background-color:#{0};"">
                                            <tr>
                                                <td align=""left"" valign=""top"" style=""{2}"" width=""{5}%"">
                                                    <table border=""0"" width=""100%"" cellpadding=""0"" cellspacing=""0"">
                                                        <tr>
                                                            <td {1} >
{6}
                                                                <img class=""resizeImg"" style=""display:block;"" src=""{3}"" alt=""{4}"" >
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
								</table>
                        </td>
                    </tr>
                    <!-- body part 1 closed -->
                </table>

            </td>
        </tr>", img.background_color, img.alignment, img.style, "images/" + img.imagePath.Substring(img.imagePath.LastIndexOf("\\")), img.alternateText, img.width, img.alink);
                    //concentrate
                    list.Add(img);
                }
                if (row.Cells["Type"].Value.ToString() == "Text")
                {
                    AdiText txt = (AdiText)row.Cells["Object"].Value;
                    txt.HTML = string.Format(@"<tr>
                                    <td >
                                        <table border=""0"" cellpadding=""0"" width=""640"" align=""center"" class=""templateColumns100"" cellspacing=""0"">
                                            <tr>
                                                <td {0}  style=""{1}"">
                                                    <span>
                                                       {2}
													   </span>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>", txt.alignment, txt.style, txt.text);

                    list.Add(txt);
                }
                if (row.Cells["Type"].Value.ToString() == "Spacer")
                {
                    AdiSpacer spc = (AdiSpacer)row.Cells["Object"].Value;
                    spc.HTML = string.Format(@"<tr>
                                    <td height=""{0}"" align=""center"" valign=""middle"" style=""font-size:0; mso-line-height-alt:0; mso-margin-top-alt:1px;background-color:{1};"">
                                        <img height=""{0}"" src=""{2}"" border=""0"" alt="""" style=""display:block;"">
                                    </td>
                                </tr>", spc.Height, spc.BgColor, spc.Link);
                    list.Add(spc);


                }
                if (row.Cells["Type"].Value.ToString() == "1Xi Text")
                {
                    AdiText_1xi add = (AdiText_1xi)row.Cells["Object"].Value;
                    StringBuilder spc = new StringBuilder();
                    foreach (var item in add.controls)
                    {
                        spc.Append(string.Format(@"<td  {0} style=""padding:0px; margin:0px;"" class=""templateColumnContainer"" width=""{1}"">
                                                                <table width=""100%""  style=""mso-table-lspace:0pt; mso-table-rspace:0pt;"" align=""left"" border=""0"" cellpadding=""0"" cellspacing=""0"" class=""templateColumns100"">
                                                                    <tbody><tr>
                                                                        <td {0} style=""{2}"" >{3}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        
                                                                    </tr>
                                                                    </tbody></table>
                                                             </td>", item.GetAlignmentValues(), 640 / add.elements, item.GetValueOfStyle(), item.GetText()));
                    }
                    add.HTML = string.Format(@"<tr>
                        <td align=""center"" valign=""top"">
                            <!-- Purchase Summary part starts -->        
                            <table cellspacing=""0"" cellpadding=""0"" width=""100%"" align=""center"" border=""0"">
                                <tr>
                                     <td align=""center"" valign=""top"">        
                                        <table border=""0"" width=""640"" cellpadding=""0"" cellspacing=""0"" class=""container""><tr>
                                                <td align=""left"" valign=""top"">
                                                    <table class=""templateColumns100"" cellpadding=""0"" cellspacing=""0"" border=""0"">
                                                        <tbody><tr>{0}  </tr>
                                                    </tbody></table>
                                                </td>
                                            </tr> </table>        
                                    </td>
                                </tr>
                            </table>
                            <!-- Purchase Summary part closed -->        
                        </td>
                    </tr> ", spc.ToString());

                    list.Add(add);

                }


                if (row.Cells["Type"].Value.ToString() == "1Xi Image")
                {
                    AdiImage_1xi spc = (AdiImage_1xi)row.Cells["Object"].Value;
                    StringBuilder sb = new StringBuilder();

                    foreach (var item in spc.controls)
                    {
                        string partialBlock = String.Format(@"<td {4} style=""{3}"" class=""story-left"" width=""{2}"">
          <table border=""0"" width=""100%"" cellpadding=""0"" cellspacing=""0"">
            <tr>
              <td {4}>
                {1}<img class=""resizeImg"" style=""display:block;"" border=""0"" src=""{0}"" alt=""{5}"" />
                </a>
              </td>
            </tr>
			</table>
			</td>", "images/" + item.Img.imagePath.Substring(item.Img.imagePath.LastIndexOf("\\")), item.Img.alink, item.Img.width != null ? item.Img.width : 640 / spc.elements
                 , item.GetTdStyleProperties(), item.GetAlignmentValues(), item.Img.alternateText

                 );
                        sb.Append(partialBlock);
                    }

                    spc.HTML = string.Format(@"<tr>
  <td align=""center"" valign=""top"" style=""{1}"">
    <table border=""0"" width=""640"" cellpadding=""0"" cellspacing=""0"" class=""container"" style=""{1}"">
      <tr>
{0}
</tr>
			</table>
			</td>
			</tr>
			", sb.ToString(), spc.controls.First().Img.background_color);
                    list.Add(spc);
                }
            }
            try
            {
                WriteContents(list);
                MessageBox.Show("HTML created Successfully");
            }
            catch
            {

            }
        }

        public void WriteContents(List<object> list)
        {

            FileStream file = null;
            StreamWriter writerObj = null;

            #region body

            string data = @"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html lang=""en"">
<head>
    <title>adidas</title>

    <meta name=""viewport"" content=""initial-scale=1.0"">    <!-- So that mobile webkit will display zoomed in -->
    <meta name=""format-detection"" content=""telephone=no""> <!-- disable auto telephone linking in iOS -->
    <style>
        .ReadMsgBody {
            width: 100%;
            background-color: #fff;
        }

        .ExternalClass {
            width: 100%;
            background-color: #fff;
        }

            .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {
                line-height: 100%;
            }

        body {
            -webkit-text-size-adjust: none;
            -ms-text-size-adjust: none;
        }

        table {
            border-spacing: 0;
            border-collapse: collapse;
            mso-table-lspace: 0;
            mso-table-rspace: 0;
        }

            table td {
                border-collapse: collapse;
                mso-table-lspace: 0;
                mso-table-rspace: 0;
            }

        .yshortcuts a {
            border-bottom: none !important;
        }

        .appleLinks {
            font-family: Arial;
            color: #666666 !important;
            text-decoration: none;
        }

        .appleLinks-grey a {
            color: #828280 !important;
            text-decoration: none;
        }

        .appleLinks-white a {
            color: #fff !important;
            text-decoration: none;
        }

        #appleLinks-newgrey a {
            color: #5d5d5d !important;
            text-decoration: none;
        }

        p {
            margin: 0;
            padding: 0;
            margin-bottom: 0;
        }

        body {
            -webkit-text-size-adjust: none;
            -ms-text-size-adjust: none;
        }

        body {
            margin: 0;
            padding: 0;
        }

        img {
            border: 0;
        }

        table {
            border-spacing: 0;
            border-collapse: collapse;
            mso-table-lspace: 0;
            mso-table-rspace: 0;
        }

            table td {
                border-collapse: collapse;
                mso-table-lspace: 0;
                mso-table-rspace: 0;
            }

        appleLinks-white a {
            color: #fff !important;
            text-decoration: none;
        }

        /************WNDMAN CSS******************/
        /*DO NOT EDIT*/
        @media screen and (max-width: 639px) {
            table[class=""container""] {
                width: 100% !important;
            }

            tr[class=""hideMobile""] {
                display: none;
            }

            td[class=""hideMobile""] {
                display: none !important;
            }

            td[id=""hideMobile""] {
                display: none !important;
            }

            td[class=""leftQuot""] {
                padding-left: 0 !important;
                padding-right: 8px !important;
            }

            td[class=""rightQuot""] {
                padding-right: 0 !important;
                padding-left: 8px !important;
            }

            td[class=""speech""] {
                padding-left: 0 !important;
                padding-right: 0 !important;
                text-align: left;
            }

            img[class=""hideMobile""] {
                display: none !important;
            }

            img[class=""resizeImg""] {
                width: 100% !important;
            }

            img[class=""resizeImg80""] {
                width: 80% !important;
            }

            div[class=""hideDesktop""] {
                display: block !important;
                margin: 0;
                padding: 0;
                overflow: visible !important;
                width: auto !important;
                height: auto !important;
                max-height: inherit !important;
            }

            img[class=""hideDesktop""] {
                display: block !important;
                margin: 0;
                padding: 0;
                overflow: visible !important;
                width: 100% !important;
                height: auto !important;
                max-height: inherit !important;
            }

            tr[class=""show-mobile""] {
                display: block !important;
            }

            td[class=""show-mobile""] {
                display: block !important;
                width: auto !important;
                max-height: inherit !important;
                overflow: visible !important;
                float: none !important;
            }

            td[class=""mobile-padding""] {
                padding-left: 15px !important;
                padding-right: 15px !important;
            }

            td[class=""mobile-padding-left""] {
                padding-left: 15px !important;
                padding-right: 0 !important;
            }

            td[class=""force-col""] {
                display: block;
                padding-right: 0 !important;
                width: 100%;
                border: 0 !important;
            }

            table[class=""col""] {
                float: none !important;
                width: 100% !important;
            }

            table[class=""col-3""] {
                float: none !important;
                width: 100% !important;
            }

            td[class=""centerText""] {
                text-align: center;
            }

            td[class=""linkFarmText""] {
                padding-left: 10px !important;
                font-size: 16px !important;
            }

            td[id=""resetPadding""] {
                padding: 0 !important;
            }

            td[class=""resetPadding""] {
                padding: 0 !important;
            }

            td[class=""resetBorderRightBottom""] {
                border-right: 0 !important;
                border-bottom: 0 !important;
            }

            td[class=""resetBorderRight""] {
                border-right: 1px solid #ffffff !important;
            }

            td[id=""addBorderBottom""] {
                border-bottom: 1px dashed #ebebeb !important;
            }

            td[class=""height30""] {
                height: 30px !important;
            }

            td[class=""buttonPadding""] {
                padding-left: 15px !important;
            }

            td[class=""centerImage""] {
                margin-left: auto !important;
                margin-right: auto !important;
            }

            td[class=""noBorder""] {
                border: none !important;
            }

            table[class=""width70""] {
                width: 70% !important;
            }

            table[class=""width80""] {
                width: 80% !important;
            }

            table[class=""width90""] {
                width: 90% !important;
            }

            table[class=""width95""] {
                width: 95% !important;
            }

            table[class=""width100""] {
                width: 100% !important;
            }

            table[class=""resetBorders""] {
                border: 0 !important;
            }

            table[id=""resetBorders""] {
                border: 0 !important;
            }

            td[class=""header-logo""] {
                padding-bottom: 20px !important;
                border-bottom: 1px solid #444444;
            }

            td[class=""header-menu""] {
                padding-top: 10px !important;
            }

            td[class=""height10""] {
                height: 10px !important;
            }

            img[class=""height10""] {
                height: 10px !important;
            }

            td[class=""mobile-menu-padding""] {
                width: auto !important;
                padding-left: 10px !important;
            }

            table[id=""footer-border-bottom""] {
                border-bottom: 1px solid #ebebeb !important;
            }

            td[class=""reset-height""] {
                height: auto !important;
            }

            table[class=""add-top-bot-margin""] {
                margin-top: 30px !important;
                margin-bottom: 30px !important;
            }

            table[id=""footer-menu""] td {
                display: inline-block;
            }

            table[id=""footer-menu""] {
                text-align: center;
                line-height: 20px;
            }

            td[class=""mobile-font-16""] {
                font-size: 16px !important;
            }

            td[class=""mobile-font-14""] {
                font-size: 14px !important;
            }

            td[class=""mobile-font-12""] {
                font-size: 12px !important;
            }

            table[id=""padding-20""] {
                margin-left: 20px;
            }

            table tr td img[id=""action""] {
                margin-left: 5px;
            }

            table[id=""action2""] {
                margin-top: 15px;
            }

            td[class=""height20""] {
                height: 20px !important;
            }

            table[id=""marg-bot-20""] {
                margin-bottom: 20px !important;
            }

            td[class=""mobile-font-25""] {
                font-size: 25px !important;
            }

            td[class=""story-left""] {
                padding-left: 15px !important;
                padding-right: 7px !important;
            }

            td[class=""story-right""] {
                padding-left: 7px !important;
                padding-right: 15px !important;
            }

            td[class=""voucher-btn""] a {
                font-weight: normal !important;
                font-size: 18px !important;
            }

            table[id=""add-bot-margin-10""] {
                margin-bottom: 10px !important;
            }

            table[id=""add-bot-margin-30""] {
                margin-bottom: 30px !important;
            }

            table[class=""dialog-btn""] {
                width: 200px !important;
                margin-top: 20px !important;
            }

            span[class=""dialog-font""] {
                display: block !important;
                font-size: 16px !important;
            }

            td[class=""font14-reset-lineheight""] {
                font-size: 14px !important;
                line-height: 18px !important;
            }

            td[id=""width50""] {
                width: 50% !important;
            }

            td[class=""mobile-font-17""] {
                font-size: 16px !important;
            }

            td[class=""resetheight""] {
                height: auto;
            }
        }
        /*DO NOT EDIT*/
        /************WNDMAN CSS******************/
        @media screen and (max-width: 639px) {
            .autoheight {
                height: auto !important;
            }

            .responsive-banner-image {
                width: 100% !important;
            }

            .changeBorder2 {
                border-right: 0 !important;
                border-bottom: 10px solid #EAEAEA;
            }

            .alignMobile {
                display: block !important;
                width: 100% !important;
                align: center !important;
                padding-left: 55px !important;
            }

            .alignMobile1 {
                display: block !important;
                align: center !important;
                padding-left: 55px !important;
            }

            .paddingTopMobile {
                padding-top: 10px !important;
            }

            .paddingMobile {
                padding-top: 10px !important;
                padding-bottom: 10px !important;
                align: center !important;
                text-align: center !important;
            }

            .hideMobile {
                display: none;
            }

            .fasteasyCheckout_padding {
                border-right: 0 none !important;
                padding-top: 40px !important;
                width: 100% !important;
            }

            .productContainer_image {
                width: 200px !important;
                float: left !important;
            }

            .productImage_abandonbrowse {
                width: 200px !important;
            }

            .newHeight2 {
                height: 0 !important;
                font-size: 0 !important;
            }

            .leftMargin {
                padding-left: 27px !important;
                text-align: left !important;
            }

            .leftMarginShopnow {
                padding-left: 18px !important;
            }

            .acCodetxtwidth {
                width: 94% !important;
            }

            .width100 {
                width: 100% !important;
            }

            .fasteasyCheckout_paddingTabletoppadding {
                padding-top: 40px !important;
            }

            .templateColumns {
                width: 320px !important;
            }

            .templateColumns100 {
                width: 100% !important;
            }

            .templateColumnContainer {
                display: block !important;
                width: 100% !important;
            }

            .deliveryBlockContainer {
                border-bottom: 1px solid #ebebeb;
                border-right: 0 none !important;
                padding-bottom: 40px !important;
                width: 100% !important;
            }



            .buttonpaddingBottom {
                padding-bottom: 10px !important;
            }

            .leftMargin2 {
                border: 0 !important;
                padding-left: 27px !important;
            }

            table[class=""aem-main-wrapper""] {
                width: 100% !important;
            }

            td[class=""aem-hide-mobile""] {
                display: none !important;
            }

            td[class=""aem-main-wrapper""] {
                width: 100% !important;
                display: block !important;
            }

            table[class=""aem-width100""] {
                width: 100% !important;
            }

            td[class=""aem-align-centertxt""] {
                text-align: center;
            }

            img[class=""aem-img-resize""] {
                width: 100% !important;
            }

            img[class=""aem-prd-img""] {
                width: 93% !important;
            }

            a[class=""aem-free-delivery""] {
                font-size: 11px !important;
                font-weight: 400 !important;
            }

            td[class=""aem-shrink-txt""] {
                font-size: 14px !important;
            }

            table[class=""aem-message-wrapper""] {
                width: 99.8% !important;
            }

            td[class=""aem-main-left-wrapper""], td[class=""aem-main-right-wrapper""] {
                width: 97.5% !important;
                display: block !important;
            }

            table[class=""aem-side-bar-exp-left""], table[class=""aem-order-details""] {
                width: 100% !important;
            }

            table[class=""aem-side-bar-right""] {
                border-top: 5px solid #EAEAEA !important;
            }

            table[class=""aem-order-details""] {
                border-top: 5px solid #EAEAEA !important;
            }

            table[class=""aem-you-like""] {
                width: 100% !important;
            }

            td[class=""aem-ord-detl-heading""] {
                padding-left: 10px !important;
            }

            td[class=""aem-order-wrapper""] {
                width: 97% !important;
                display: block !important;
            }

            td[class=""aem-prd-desc aem-desc1""], td[class=""aem-col-heading""], td[class=""aem-col-row""] {
                font-size: 11px !important;
                word-wrap: break-word;
            }

            table[class=""aem-prd-table""] {
                width: 100% !important;
            }

            td[class=""aem-dynamic-txt""] {
                font-size: 30px !important;
            }

            td[class=""aem-footer-links-last""], td[class=""aem-footer-links""] {
                padding: 10px 0 !important;
            }

            td[class=""aem-footer-links-last""] {
                border-bottom: 0 !important;
            }

            td[class=""aem-order-container""] {
                width: 100% !important;
                display: block !important;
            }

            td[class=""aem-order-mid-container""] {
                width: 96% !important;
                display: block !important;
                padding: 0 !important;
                padding-left: 8px !important;
            }

            table[class=""aem-order-mid-table""] {
                border-top: 1px solid #cacaca;
                padding-left: 10px !important;
            }

            table[class=""aem-order-mid-table-top""] {
                border-top: 0 solid #cacaca;
                padding-left: 10px !important;
            }

            td[class=""aem-bottom""] {
                padding-bottom: 10px !important;
            }

            td[class=""aem-top""] {
                padding-top: 10px !important;
            }

            td[class=""aem-step-order""] {
                width: 225px !important;
            }
        }

        @media screen and (max-width: 480px) {
            .ordersummrypadding10 {
                padding-left: 10px !important;
            }

            .changeBorder2 {
                border-right: 0 !important;
                border-bottom: 10px solid #EAEAEA;
            }

            .autoheight {
                height: auto !important;
            }

            .alignMobile {
                display: block !important;
                width: 100% !important;
                align: center !important;
                padding-left: 55px !important;
            }

            .alignMobile1 {
                display: block !important;
                align: center !important;
                padding-left: 55px !important;
            }

            td[class=""aem-shrink-txt""] {
                font-size: 11px !important;
            }

            table[class=""aem-message-wrapper""] {
                width: 99% !important;
            }

            td[class=""aem-main-wrapper""] {
                width: 96% !important;
                display: block !important;
            }

            td[class=""aem-main-left-wrapper""], td[class=""aem-main-right-wrapper""] {
                width: 96% !important;
                display: block !important;
            }

            img[class=""aem-prd-img""] {
                width: 120% !important;
            }

            td[class=""aem-order-wrapper""] {
                width: 95% !important;
                display: block !important;
            }

            table[class=""aem-prd-table""] {
                width: 102% !important;
            }

            td[class=""aem-dynamic-txt""] {
                font-size: 25px !important;
            }

            td[class=""aem-question-one""] {
                width: 100% !important;
                display: block !important;
                padding-bottom: 10px !important;
            }

            td[class=""aem-questions-two""] {
                padding: 0 !important;
            }

            td[class=""aem-second-row""] {
                width: 85% !important;
                display: block !important;
                padding-bottom: 10px !important;
                padding-left: 10px !important;
            }

            td[class=""aem-second-col""] {
                width: 85% !important;
                display: block !important;
                padding-bottom: 10px !important;
                padding-left: 20px !important;
            }

            td[class=""aem-youmay-like""] {
                font-size: 24px !important;
            }

            .hideMobile {
                display: none !important;
            }

            .width100 {
                width: 100% !important;
            }

            .leftMargin {
                padding-left: 27px !important;
                text-align: left !important;
            }

            .lessleftMargin {
                padding-left: 16px !important;
            }

            .responsive-banner-image {
                width: 100% !important;
            }

            .width290 {
                width: 290px !important;
            }

            .hideDesktop {
                display: block !important;
            }

            .productImage {
                width: 60% !important;
            }

            .lessleftMargin45 {
                padding-left: 60px !important;
                text-align: left !important;
            }

            .lessleftMargin80 {
                padding-left: 45px !important;
                text-align: left !important;
                width: 100% !important;
            }

            .arrow-white1 {
                padding-left: 65px !important;
            }

            .arrow-white2 {
                padding-left: 38px !important;
            }

            .arrow-white3 {
                padding-left: 60px !important;
            }

            .width40 {
                width: 50% !important;
            }

            .midbutton {
                width: 80% !important;
            }

            .productContainer_image {
                width: 130px !important;
                float: left !important;
                padding: 8px 10px;
            }

            .productImage_abandonbrowse {
                width: 140px !important;
            }

            .paddingProductcontainer {
                padding: 0 10px !important;
            }

            .newHeight {
                height: 0 !important;
            }


            .width320 {
                width: 320px !important;
            }

            .productsContainerE1 {
                padding: 0 !important;
            }

            .productCol {
                width: 310px !important;
            }
        }

        @media only screen and (max-width: 639px) {
            .leftMargin3 {
                border: 0 !important;
                padding-left: 60px !important;
            }
        }

        @media screen and (max-width: 320px) {
            table[class=""aem-main-wrapper""] {
                width: 320px !important;
            }

            table[class=""aem-message-wrapper""] {
                width: 99% !important;
            }

            td[class=""aem-main-wrapper""] {
                width: 95% !important;
                display: block !important;
            }

            td[class=""aem-main-left-wrapper""], td[class=""aem-main-right-wrapper""] {
                width: 96% !important;
                display: block !important;
            }

            img[class=""aem-prd-img""] {
                width: 120% !important;
            }

            table[class=""aem-prd-table""] {
                width: 101% !important;
            }
        }
        /*******************font-Size-definition Mobile***********************************/
        @media screen and (max-width: 639px) {
            .fontSize72 {
                font-size: 36px !important;
                font-weight: 700 !important;
            }

            .fontSize48 {
                font-size: 24px !important;
                font-weight: 700 !important;
            }

            .fontSize32 {
                font-size: 16px !important;
                font-weight: 700 !important;
            }

            .fontSize70 {
                font-size: 45px !important;
                font-weight: 700 !important;
            }

            .fontSize46 {
                font-size: 30px !important;
                font-weight: 700 !important;
            }

            .fontSize28 {
                font-size: 19px !important;
                font-weight: 700 !important;
            }

            .fontSize24 {
                font-size: 16px !important;
                font-weight: 700 !important;
            }

            .fontSize18 {
                font-size: 14px !important;
                font-weight: 700 !important;
            }

            .fontSize17 {
                font-size: 14px !important;
                font-weight: 700 !important;
            }

            .fontSize14 {
                font-size: 13px !important;
                font-weight: 400 !important;
            }

            .fontSize13 {
                font-size: 12px !important;
                font-weight: 400 !important;
            }

            .fontSize18n {
                font-size: 14px !important;
                font-weight: 400 !important;
            }

            .buttonAjustHeight {
                height: 33px !important;
            }

            .fontadjust12 {
                font-size: 12px !important;
            }

            .paddingTop48 {
                padding-top: 48px !important;
            }

            .paddingTop32 {
                padding-top: 32px !important;
            }
        }


        .headcolor {
            color: #999999 !important;
        }

        @media screen and (max-width: 639px) {
            .paddingMobileZero {
                display: block !important;
                width: 100% !important;
                padding-right: 0px !important;
            }
        }

        @media screen and (max-width: 639px) {


            .shoepadding {
                padding-left: 30px !important;
            }

            .mobilecenter {
                text-align: center !important;
            }

            .paddingzero {
                padding-right: 0px !important;
                padding-left: 0px !important;
            }

            .mobiletextpadding {
                padding-left: 10px;
                padding-right: 10px;
            }

            .leftpaddingmobile {
                padding-left: 10px;
            }

            .fontadjust10 {
                font-size: 14px !important;
                padding-top: 5px !important;
            }

            .tablecolorchange {
                display: block !important;
                width: 100% !important;
                background-color: #FFFFFF;
                padding-top: 5px !important;
                padding-bottom: 5px !important;
            }

            .textcolor {
                color: #000000 !important;
            }

            .paddingtop {
                padding-top: 0px !important;
            }

            .bordermobile {
                border-right: 0px !important;
            }

            .mobilebottomborder {
                display: block !important;
                width: 100% !important;
                border-bottom: 1px solid #f2f2f2;
            }

            .paddingzero480 {
                padding-left: 0px !important;
                padding-top: 10px !important;
            }

            .mobilepaddingheader {
                display: block !important;
                width: 100% !important;
                padding-top: 5px !important;
                padding-bottom: 5px !important;
            }

            .paddingobjectives {
                width: 100% !important;
                padding-left: 60px !important;
            }

            .paddinglogo {
                padding-left: 150px !important;
            }
        }



        @media screen and (max-width: 480px) {


            .paddingzero480 {
                padding-left: 0px !important;
            }

            .fontadjust10 {
                font-size: 8px !important;
            }

            .paddingtop {
                padding-bottom: 0px !important;
            }
        }


        @font-face {
            font-family: 'AdiHausPS_BD';
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/AdihausDIN-Bold.eot'); /* IE9 Compat Modes */
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/AdihausDIN-Bold.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */
            url('http://test.adidas-news.adidas.com/res/adidas-test/AdihausDIN-Bold.woff') format('woff'), /* Modern Browsers */
            url('http://test.adidas-news.adidas.com/res/adidas-test/AdihausDIN-Bold.ttf') format('truetype'); /* Safari, Android, iOS */
        }



        @font-face {
            font-family: 'ColfaxWebBlack';
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/ColfaxWebBlack.eot'); /* IE9 Compat Modes */
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/ColfaxWebBlack.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */
            url('http://test.adidas-news.adidas.com/res/adidas-test/ColfaxWebBlack.woff') format('woff'), /* Modern Browsers */
            url('http://test.adidas-news.adidas.com/res/adidas-test/ColfaxWebBlack.ttf') format('truetype'); /* Safari, Android, iOS */
        }

        @font-face {
            font-family: 'ReefontRegular';
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/Reefont-Regular.eot'); /* IE9 Compat Modes */
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/Reefont-Regular.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */
            url('http://test.adidas-news.adidas.com/res/adidas-test/Reefont-Regular.woff') format('woff'), /* Modern Browsers */
            url('http://test.adidas-news.adidas.com/res/adidas-test/Reefont-Regular.ttf') format('truetype'); /* Safari, Android, iOS */
        }

        @font-face {
            font-family: 'ReefontBold';
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/Reefont-Bold.eot'); /* IE9 Compat Modes */
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/Reefont-Bold.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */
            url('http://test.adidas-news.adidas.com/res/adidas-test/Reefont-Bold.woff') format('woff'), /* Modern Browsers */
            url('http://test.adidas-news.adidas.com/res/adidas-test/Reefont-Bold.ttf') format('truetype'); /* Safari, Android, iOS */
        }

        @font-face {
            font-family: 'ArialBlack';
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/arial_black.eot'); /* IE9 Compat Modes */
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/arial_black.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */
            url('http://test.adidas-news.adidas.com/res/adidas-test/arial_black.woff') format('woff'), /* Modern Browsers */
            url('http://test.adidas-news.adidas.com/res/adidas-test/arial_black.ttf') format('truetype'); /* Safari, Android, iOS */
        }




        /*******************font-Size-definition Desktop***********************************/
        .fontSize72 {
            font-size: 72px !important;
            font-weight: 700 !important;
        }

        .fontSize48 {
            font-size: 48px !important;
            font-weight: 700 !important;
        }

        .fontSize32 {
            font-size: 32px !important;
            font-weight: 700 !important;
        }

        .fontSize70 {
            font-size: 70px !important;
            font-weight: 700 !important;
        }

        .fontSize46 {
            font-size: 46px !important;
            font-weight: 700 !important;
        }

        .fontSize28 {
            font-size: 28px !important;
            font-weight: 700 !important;
        }

        .fontSize24 {
            font-size: 24px !important;
            font-weight: 700 !important;
        }

        .fontSize18 {
            font-size: 18px !important;
            font-weight: 700 !important;
        }

        .fontSize17 {
            font-size: 17px !important;
            font-weight: 700 !important;
        }

        .fontSize14 {
            font-size: 14px !important;
            font-weight: 400 !important;
        }

        .fontSize13 {
            font-size: 13px !important;
            font-weight: 400 !important;
        }

        .fontSize18n {
            font-size: 18px !important;
            font-weight: 400 !important;
        }

        /*******************font-Size-definition Mobile***********************************/
        @media screen and (max-width: 639px) {
            .fontSize72 {
                font-size: 36px !important;
                font-weight: 700 !important;
            }

            .fontSize48 {
                font-size: 24px !important;
                font-weight: 700 !important;
            }

            .fontSize32 {
                font-size: 16px !important;
                font-weight: 700 !important;
            }

            .fontSize70 {
                font-size: 45px !important;
                font-weight: 700 !important;
            }

            .fontSize46 {
                font-size: 30px !important;
                font-weight: 700 !important;
            }

            .fontSize28 {
                font-size: 19px !important;
                font-weight: 700 !important;
            }

            .fontSize24 {
                font-size: 16px !important;
                font-weight: 700 !important;
            }

            .fontSize18 {
                font-size: 14px !important;
                font-weight: 700 !important;
            }

            .fontSize17 {
                font-size: 14px !important;
                font-weight: 700 !important;
            }

            .fontSize14 {
                font-size: 13px !important;
                font-weight: 400 !important;
            }

            .fontSize13 {
                font-size: 12px !important;
                font-weight: 400 !important;
            }

            .fontSize18n {
                font-size: 14px !important;
                font-weight: 400 !important;
            }

            .buttonAjustHeight {
                height: 33px !important;
            }

            .fontadjust12 {
                font-size: 12px !important;
            }

            .paddingTop48 {
                padding-top: 48px !important;
            }

            .paddingTop32 {
                padding-top: 32px !important;
            }

            .paddingfooter {
                padding-left: 10px;
            }
        }
    </style>
</head>

<body style=""margin:0; padding: 0;"" bgcolor=""#ffffff"" leftmargin=""0"" topmargin=""0"" marginwidth=""0"" marginheight=""0"">

    <span style=""display:none !important; mso-hide:all;"">Ton accès privilègiè</span>

    <table border=""0"" width=""100%"" height=""100%"" cellpadding=""0"" cellspacing=""0"">

        <!-- Collect information about promo_codes -->
        <!-- ************************ BEGIN RENDER HEADER ************************ -->
        <tr><td align=""center"" valign=""top"">
        <tr>
            <td align=""center"" valign=""top"" style=""background-color:#ffffff;"" bgcolor=""#ffffff"">
                <table border=""0"" width=""640"" cellpadding=""0"" cellspacing=""0"" class=""container"" style=""background-color:#ffffff;"" bgcolor=""#ffffff"">
                    <tr>
                        <td align=""left"" valign=""top"">
                            <table border=""0"" width=""100%"" cellpadding=""0"" cellspacing=""0"">
                                <tr>
                                    <td height=""15"" align=""left"" valign=""middle"" style=""font-size:0; mso-line-height-alt:0; mso-margin-top-alt:1px;"">
                                        <img height=""15"" src=""http://test.adidas-news.adidas.com/res/adidas-test/spacer.gif"" border=""0"" alt="""" style=""display:block;"">
                                    </td>
                                </tr>
                                <tr>
                                    <td align=""left"" valign=""top"" style=""font-family:Arial; font-size:12px; color:#0185cc;"" class=""hideMobile"">


                                        <a style=""color:#0185cc; text-decoration:none;"" href="" http://t.neocrm-stg.adidas.com//r/?id=h22174bed,15bc2dc8,15bc2dda"" _label=""Promo"" target=""_blank"">Utilise ta récompense</a>


                                    </td>
                                    <td align=""right"" valign=""top"" style=""font-family:Arial; font-size:12px; color:#0185cc;"" class=""centerText"">

                                        <a href="" http://t.neocrm-stg.adidas.com//r/?id=h22174bed,15bc2dc8,15bc2ddb&amp;p1=i6R1uhWroHu2hEcceaZADHZEHYCpBP3O&amp;p2=63035078"" _type=""mirrorPage"" _label=""Mirror Page"" target=""_blank"" style=""color:#0185cc; text-decoration:none;"">Voir cet e-mail en ligne</a>

                                    </td>
                                </tr>
                                <tr>
                                    <td height=""15"" align=""left"" valign=""middle"" style=""font-size:0; mso-line-height-alt:0; mso-margin-top-alt:1px;"">
                                        <img height=""15"" src=""http://test.adidas-news.adidas.com/res/adidas-test/spacer.gif"" border=""0"" alt="""" style=""display:block;"">
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr></td></tr>
        <tr><td align=""center"" valign=""top"">
        <tr>
            <td align=""center"" valign=""top"" style=""background-color:#000000;"" bgcolor=""#000000"">
                <table border=""0"" width=""640"" cellpadding=""0"" cellspacing=""0"" class=""container"" style=""background-color:#000000;"" bgcolor=""#000000"">
                    <tr>
                        <td align=""left"" valign=""top"">
                            <table border=""0"" cellpadding=""0"" cellspacing=""0"" width=""100%"">
                                <tr>
                                    <td height=""18"" align=""left"" valign=""middle"" style=""font-size:0; mso-line-height-alt:0; mso-margin-top-alt:1px;"">
                                        <img height=""18"" src=""http://test.adidas-news.adidas.com/res/adidas-test/spacer.gif"" border=""0"" alt="""" style=""display:block;"">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table border=""0"" cellspacing=""0"" cellpadding=""0"" width=""100%"" align=""left"" class=""col"">
                                            <tr>
                                                <td align=""left"" valign=""top"">

                                                    <table width=""160"" class=""container"" border=""0"" align=""left"" cellpadding=""0"" cellspacing=""0"">
                                                        <tr>
                                                            <td align=""center"" valign=""top"" class=""header-logo"">
                                                                <a href="" http://t.neocrm-stg.adidas.com//r/?id=h22174bed,15bc2dc8,15bc2ddc"" _label=""youradidas logo"" title=""youradidas logo"" target=""_blank"">
                                                                    <img width=""160"" alt=""youradidas logo"" src=""http://test.adidas-news.adidas.com/res/adidas-test/adi_Brd_Loyalty_Logo_v2.jpg"" border=""0"" alt=""0"" style=""display:block;"">
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <!--[if mso]></td><td align=""left"" valign=""top""><![endif]-->
                                                    <table width=""480"" class=""container"" border=""0"" align=""right"" cellpadding=""0"" cellspacing=""0"">
                                                        <tr>
                                                            <td height=""3"" align=""left"" valign=""middle"" style=""font-size:0; mso-line-height-alt:0; mso-margin-top-alt:1px;"" class=""hideMobile"">
                                                                <img height=""3"" src=""http://test.adidas-news.adidas.com/res/adidas-test/spacer.gif"" border=""0"" alt="""" style=""display:block;"">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align=""left"" valign=""middle"" height=""19"" class=""header-menu"" style=""padding-left:10px;"" id=""resetPadding"">
                                                                <table border=""0"" cellpadding=""0"" cellspacing=""0"">
                                                                    <tr>
                                                                        <td align=""left"" valign=""middle"" style=""font-family:Arial; font-size:13px; color:#ffffff; padding-left:20px;"" class=""mobile-menu-padding"">
                                                                            <a href="""" _label="""" target=""_blank"" style=""color:#ffffff; text-decoration:none;""><strong></strong></a>
                                                                        </td>
                                                                        <td align=""left"" valign=""top"" style=""font-family:Arial; font-size:13px; color:#ffffff; padding-left:20px;"" class=""mobile-menu-padding"">
                                                                            <a href="""" _label="""" target=""_blank"" style=""color:#ffffff; text-decoration:none;""><strong></strong></a>
                                                                        </td>
                                                                        <td align=""left"" valign=""top"" style=""font-family:Arial; font-size:13px; color:#ffffff; padding-left:20px;"" class=""mobile-menu-padding"">
                                                                            <a href="""" _label="""" target=""_blank"" style=""color:#ffffff; text-decoration:none;""><strong></strong></a>
                                                                        </td>
                                                                        <td align=""left"" valign=""top"" style=""font-family:Arial; font-size:13px; color:#ffffff; padding-left:20px;"" class=""hideMobile"">
                                                                            <a href="""" _label="""" target=""_blank"" style=""color:#ffffff; text-decoration:none;""><strong></strong></a>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </td>
                                                            <td align=""right"" valign=""middle"" class=""header-menu"">
                                                                <table border=""0"" cellpadding=""0"" cellspacing=""0"">
                                                                    <tr>
                                                                        <td align=""right"" valign=""middle"" style=""font-family:Arial; font-size:13px; color:#ffffff; padding-right:8px;"" class=""mobile-menu-padding"">
                                                                            <a href="""" _label="""" target=""_blank"" style=""color:#ffffff; text-decoration:none;""><strong>Trouver un magasin</strong></a>
                                                                        </td>
                                                                        <td align=""right"" valign=""middle"" class=""hideMobile"">
                                                                            <img src=""http://test.adidas-news.adidas.com/res/adidas-test/adi_omni_channel_newsletter_footer_icon_storefinder.jpg"" border=""0"" alt=""0"" style=""display:block"">
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </table>

                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td height=""20"" align=""left"" valign=""middle"" style=""font-size:0; mso-line-height-alt:0; mso-margin-top-alt:1px;"" class=""height10"">
                                        <img height=""20"" src=""http://test.adidas-news.adidas.com/res/adidas-test/spacer.gif"" border=""0"" alt="""" style=""display:block;"" class=""height10"">
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr></td></tr>
        <tr><td align=""center"" valign=""top""></td></tr>
        <tr><td align=""center"" valign=""top""></td></tr>

        <!-- ************************ END RENDER HEADER ************************ -->
        <!-- ************************ BEGIN BODY CONTENT ************************ -->
";

            #endregion body

            try
            {
                var systemPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                var complete = System.IO.Path.Combine(systemPath, "Automated HTML"); // For creating a Folder In My Documents
                string fullpath = GetUniqueTempPath(complete);
                string imagepath = System.IO.Path.Combine(fullpath, "images");
                if (!Directory.Exists(fullpath))
                {
                    Directory.CreateDirectory(fullpath);
                    Directory.CreateDirectory(imagepath);
                }
                file = new FileStream(System.IO.Path.Combine(fullpath, "generatedHtml.txt"), FileMode.Create);
                writerObj = new StreamWriter(file);
                writerObj.Write(QuoteSQLString(data));
                foreach (object item in list)
                {
                    if (item.GetType() == typeof(AdiImage))
                    {
                        AdiImage img = (AdiImage)item;
                        File.Copy(img.imagePath, imagepath + img.imagePath.Substring(img.imagePath.LastIndexOf("\\")), true);
                        writerObj.Write(QuoteSQLString(img.HTML));
                    }
                    if (item.GetType() == typeof(AdiText))
                    {
                        AdiText txt = (AdiText)item;
                        writerObj.Write(QuoteSQLString(txt.HTML));
                    }
                    if (item.GetType() == typeof(AdiSpacer))
                    {
                        AdiSpacer spc = (AdiSpacer)item;
                        writerObj.Write(QuoteSQLString(spc.HTML));
                    }
                    if (item.GetType() == typeof(AdiImage_1xi))
                    {
                        AdiImage_1xi spc = (AdiImage_1xi)item;

                        StringBuilder sb = new StringBuilder();

                        foreach (var itemImg in spc.controls)
                        {
                            File.Copy(itemImg.Img.imagePath, imagepath + itemImg.Img.imagePath.Substring(itemImg.Img.imagePath.LastIndexOf("\\")), true);


                        }
                        writerObj.Write(QuoteSQLString(spc.HTML));
                    }
                    if (item.GetType() == typeof(AdiText_1xi))
                    {
                        AdiText_1xi spc = (AdiText_1xi)item;
                        writerObj.Write(QuoteSQLString(spc.HTML));
                    }
                }
                writerObj.Write("</td></tr></table></body></html>");
            }
            catch (Exception ex)
            {
                //FileException.Add("" + ex.Message);
            }
            finally
            {
                if (writerObj != null)
                    writerObj.Close();
                if (file != null)
                    file.Close();
            }
        }

        public static string GetUniqueTempPath(string sPath)
        {
            string sUniqueName = Guid.NewGuid().ToString();
            //const string extension = ".txt";
            return System.IO.Path.Combine(sPath, sUniqueName);
        }

        private string QuoteSQLString(string str)
        {
            return str.Replace("\"\"", "\"");
        }

        private void btnClone_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (DataGridViewRow item in dgvStructure.SelectedRows)
                {
                    //DataGridViewRow clonedRow = (DataGridViewRow)item.Clone();
                    //for (Int32 index = 0; index < item.Cells.Count; index++)
                    //{
                    //    clonedRow.Cells[index].Value = item.Cells[index].Value;
                    //}
                    dgvStructure.Rows.Add(item);
                }
            }
            catch (Exception ex)
            {

            }

        }

        private void AddARow(DataTable table)
        {
            // Use the NewRow method to create a DataRow with 
            // the table's schema.
            DataRow newRow = table.NewRow();

            // Add the row to the rows collection.
            table.Rows.Add(newRow);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvStructure.SelectedRows != null)
            {
                DialogResult r = MessageBox.Show("Do you want to delete this item?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (r == DialogResult.Yes)
                {
                    foreach (DataGridViewRow item in dgvStructure.SelectedRows)
                    {
                        dgvStructure.Rows.Remove(item);
                    }
                }
            }
        }


    }
}
