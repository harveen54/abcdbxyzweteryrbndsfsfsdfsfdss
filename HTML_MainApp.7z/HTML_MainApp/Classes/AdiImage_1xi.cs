﻿using HTML_MainApp.UserControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace HTML_MainApp.Classes
{
    [Serializable]
    public class AdiImage_1xi : IXmlSerializable
    {
        public AdiImage[] listAdiText;
        public ucImage[] controls;

        
        public int elements;
        public string HTML;

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            reader.MoveToContent();
            // Name = reader.GetAttribute("Name");
            Boolean isEmptyElement = reader.IsEmptyElement; // (1)
            reader.ReadStartElement();
            if (!isEmptyElement) // (1)
            {
                elements = Convert.ToInt32(reader.ReadElementString("elements").ToString());
                HTML = reader.ReadElementString("HTML").ToString();
                listAdiText = new AdiImage[elements];
             
                for (int i = 0; i < elements; i++)
                {
                    AdiImage adi = new AdiImage();
                    adi.ReadXmlI(reader);
                    listAdiText[i] = adi;
                    reader.MoveToNextAttribute();
                }
       
            }

        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            //  writer.WriteStartElement("XmlSerializable");

            //writer.WriteAttributeString("Name", background_color);

            writer.WriteElementString("elements",
                  elements.ToString());

            writer.WriteElementString("HTML",
                      HTML);

            foreach(var item in listAdiText)
            {
                item.WriteXml(writer);
            }


          


           
        }
    
    }
}
