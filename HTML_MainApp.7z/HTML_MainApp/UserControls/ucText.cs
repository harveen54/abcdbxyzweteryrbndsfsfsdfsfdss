﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HTML_MainApp.Classes;

namespace HTML_MainApp.UserControls
{
    public partial class ucText : UserControl
    {
        public ucText()
        {
            InitializeComponent();
            FontP = new FontProperties();
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog();

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private bool _hasErrors;
        private FontProperties _fontP;

        public FontProperties FontP
        {
            get { return _fontP; }
            set { _fontP = value; }
        }
        public bool HasErrors
        {
            get { return _hasErrors; }
            set { _hasErrors = value; }
        }

        public void ValidateForm()
        {
            TextBox[] txtList = new TextBox[]
            {
                txtSize,
                pleft,
                pbottom,
                pright,
                ptop,
                mbottom,
                mtop,
                mright,
                mleft,
                bleft,
                bright,
                bbottom,
                btop
            };
            int flag = 0;
            foreach (TextBox txt in txtList)
            {
                if (!ValidateFields.CheckIfValueIsNumeric(txt.Text))
                {
                    flag = 1;
                    txt.BackColor = Color.Red;
                }
                else
                    txt.BackColor = Color.White;
            }
            if (flag == 1)
                HasErrors = true;
            else HasErrors = false;
        }

        public void SetAlignmentValues(FontProperties style)
        {
            if (style.hAlign == "left")
                leftAlign.Checked = true;
            else if (style.hAlign == "right")
                rightAlign.Checked = true;
            else
                centerAlign.Checked = true;


            if (style.vAlign == "top")
                vAlignTop.Checked = true;
            else if (style.hAlign == "bottom")
                vAlignBottom.Checked = true;
            else
                valignMiddle.Checked = true ;
        }
        public string GetAlignmentValues()
        {
            StringBuilder sbNew = new StringBuilder();
            if (!leftAlign.Checked && !centerAlign.Checked && !rightAlign.Checked)
            {
                sbNew.Append(string.Format("align=\"{0}\" ", "center"));
                FontP.hAlign = "center";
            }
            else
            {
                sbNew.Append(string.Format("align=\"{0}\" ", leftAlign.Checked ? "left" : (centerAlign.Checked ? "center" : "right")));
                FontP.hAlign = leftAlign.Checked ? "left" : (centerAlign.Checked ? "center" : "right");
            }
            if (!vAlignTop.Checked && !valignMiddle.Checked && !vAlignBottom.Checked)
            {
                sbNew.Append(string.Format("valign=\"{0}\" ", "middle"));
                FontP.vAlign = "middle";
            }
            else
            {
                sbNew.Append(string.Format("valign=\"{0}\" ", vAlignTop.Checked ? "Top" : (valignMiddle.Checked ? "middle" : "bottom")));
                         FontP.vAlign = vAlignTop.Checked ? "Top" : (valignMiddle.Checked ? "middle" : "bottom");
      
            }
            return sbNew.ToString();
        }

        public void SetValueOfStyle(FontProperties style)
        {
            if (style.bold)
                bold.Checked = true;
            if (style.italic)
                italic.Checked = true;
            if (style.underline)
                underline.Checked = true;

            txtSize.Text = style.font_size.ToString() ;
            txtfontColor.Text = style.color;
            txtBorderColor.Text = style.borderColor;
            txtbgcolor.Text = style.background_color;
            ptop.Text = style.pTop!=null?style.pTop.ToString():null;
            pbottom.Text = style.pBottom != null ? style.pBottom.ToString() : null;
            pleft.Text = style.pLeft != null ? style.pLeft.ToString() : null;
            pright.Text = style.pRight != null ? style.pRight.ToString() : null;

            mtop.Text = style.mTop != null ? style.mTop.ToString() : null;
            mbottom.Text = style.mBottom != null ? style.mBottom.ToString() : null;
            mleft.Text = style.mLeft != null ? style.mLeft.ToString() : null;
            mright.Text = style.mRight != null ? style.mRight.ToString() : null;


            btop.Text = style.bTop != null ? style.bTop.ToString() : null;
            bbottom.Text = style.bBottom != null ? style.bBottom.ToString() : null;
            bleft.Text = style.bLeft != null ? style.bLeft.ToString() : null;
            bright.Text = style.bRight != null ? style.bRight.ToString() : null;

        }

        public string GetValueOfStyle()
        {
            StringBuilder sb = new StringBuilder();

            if (bold.Checked)
            {
                sb.Append("font-weight:bold;");
                FontP.bold = true;
            }
            if (italic.Checked)
            {
                sb.Append("font-style: italic;");
                FontP.italic = true;
            }
            if (underline.Checked)
            {
                sb.Append(" text-decoration: underline; ");
                FontP.underline = true;
            }

            sb.Append(string.Format("font-family:{0};", cmbFamily.SelectedItem.ToString()));
            FontP.font_family = cmbFamily.SelectedItem.ToString();
            sb.Append(string.Format("font-size:{0}px;", txtSize.Text));
            FontP.font_size = Convert.ToInt32(txtSize.Text);
            sb.Append(string.Format("color:#{0};", txtfontColor.Text));
            FontP.color = txtfontColor.Text;

            sb.Append(string.Format("background-color:#{0};", txtbgcolor.Text));
            FontP.background_color = txtbgcolor.Text;

            if (!string.IsNullOrEmpty(ptop.Text))
            {
                sb.Append(string.Format("padding-top:{0}px;", ptop.Text));
                FontP.pTop = Convert.ToInt16(ptop.Text);
            }
            if (!string.IsNullOrEmpty(pbottom.Text))
            {
                sb.Append(string.Format("padding-bottom:{0}px;", pbottom.Text));
                FontP.pBottom = Convert.ToInt16(pbottom.Text);
            }

            if (!string.IsNullOrEmpty(pleft.Text))
            {
                sb.Append(string.Format("padding-left:{0}px;", pleft.Text));
                FontP.pLeft = Convert.ToInt16(pleft.Text);
            }

            if (!string.IsNullOrEmpty(pright.Text))
            {
                sb.Append(string.Format("padding-right:{0}px;", pright.Text));
                FontP.pRight = Convert.ToInt16(pright.Text);
            }

            if (!string.IsNullOrEmpty(mtop.Text))
            {
                sb.Append(string.Format("margin-top:{0}px;", mtop.Text));
                FontP.mTop = Convert.ToInt16(mtop.Text);
            }
            if (!string.IsNullOrEmpty(mbottom.Text))
            {
                sb.Append(string.Format("margin-bottom:{0}px;", mbottom.Text));
                FontP.mBottom = Convert.ToInt16(mbottom.Text);
            } if (!string.IsNullOrEmpty(mleft.Text))
            {
                sb.Append(string.Format("margin-left:{0}px;", mleft.Text));
                FontP.mLeft = Convert.ToInt16(mleft.Text);
            } if (!string.IsNullOrEmpty(mright.Text))
            {
                sb.Append(string.Format("margin-right:{0}px;", mright.Text));
                FontP.mRight = Convert.ToInt16(mright.Text);
            } if (!string.IsNullOrEmpty(bleft.Text))
            {
                sb.Append(string.Format("border-left:{0}px solid #{1};", bleft.Text, !string.IsNullOrEmpty(txtBorderColor.Text) ? txtBorderColor.Text : "000000"));
                FontP.bLeft = Convert.ToInt16(bleft.Text);
            } if (!string.IsNullOrEmpty(bright.Text))
            {
                sb.Append(string.Format("border-right:{0}px solid #{1};", bright.Text, !string.IsNullOrEmpty(txtBorderColor.Text) ? txtBorderColor.Text : "000000"));
                FontP.bRight = Convert.ToInt16(bright.Text);
            } if (!string.IsNullOrEmpty(btop.Text))
            {
                sb.Append(string.Format("border-top:{0}px solid #{1};", btop.Text, !string.IsNullOrEmpty(txtBorderColor.Text) ? txtBorderColor.Text : "000000"));
                FontP.bTop = Convert.ToInt16(btop.Text);
            } if (!string.IsNullOrEmpty(bbottom.Text))
            {
                sb.Append(string.Format("border-bottom:{0}px solid #{1};", bbottom.Text, !string.IsNullOrEmpty(txtBorderColor.Text) ? txtBorderColor.Text : "000000"));
                FontP.bBottom = Convert.ToInt16(bbottom.Text);
            
            }
            FontP.borderColor = txtBorderColor.Text;
            return sb.ToString();
        }

        public void SetText(string text)
        {
            textBox1.Text = text;
        }
        public string GetText()
        {
            return textBox1.Text;
        }
        
        private void ucText_Load(object sender, EventArgs e)
        {
            cmbFamily.SelectedIndex = 0;
        }
    }
}
