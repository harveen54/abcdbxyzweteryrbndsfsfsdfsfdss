﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HTML_MainApp.Classes;

namespace HTML_MainApp.UserControls
{
    public partial class ucImage : UserControl
    {
        //private ImageProperties _img;

        //public ImageProperties Img
        //{
        //    get { return _img; }
        //    set { _img = value; }
        //}

        private AdiImage _img;
        private bool _hasErrors;

        public bool HasErrors
        {
            get { return _hasErrors; }
            set { _hasErrors = value; }
        }
        public AdiImage Img
        {
            get { return _img; }
            set { _img = value; }
        }
        public ucImage()
        {
            InitializeComponent();
            Img = new AdiImage();
            Img.isSet = false;
            Img.isUpdated = false;
        }

        public void ValidateField()
        {
            if (openFileDialog1.FileName == null || openFileDialog1.FileName.Equals("openFileDialog1"))
            {
               
                HasErrors = true;
            }
            else
                HasErrors = false;

        }

        public void ValidateForm()
        {
            TextBox[] txtList = new TextBox[]
            {
                txtWidth,
                pleft,
                pbottom,
                pright,
                ptop,
                mbottom,
                mtop,
                mright,
                mleft,
                bleft,
                bright,
                bbottom,
                btop
            };
            int flag = 0;
            foreach (TextBox txt in txtList)
            {
                if (!ValidateFields.CheckIfValueIsNumeric(txt.Text))
                {
                    flag = 1;
                    txt.BackColor = Color.Red;
                }
                else
                    txt.BackColor = Color.White;
            }
            if (flag == 1)
                HasErrors = true;
            else HasErrors = false;
        }

        public void SetImageProperties(AdiImage img)
        {
            openFileDialog1.FileName = img.imagePath;
            txtAlternateText.Text = img.alternateText;
            txtBackground.Text = img.background_color;
            txtWidth.Text = img.width != null ? img.width.ToString() : null;
            chckLink.Checked = img.isLink;
            link.Text = img.link;
            lblFileName.Text= img.imagePath.Substring(img.imagePath.LastIndexOf('\\'));
        }
        public void GetImageProperties()
        {
            StringBuilder sb = new StringBuilder();

            string fileName = openFileDialog1.FileName;
           // sb.Append( string.Format("src=\"{0}\"",fileName));
            Img.imagePath = fileName;
            Img.alternateText = !string.IsNullOrEmpty(txtAlternateText.Text) ? txtAlternateText.Text : openFileDialog1.SafeFileName;
            sb.Append(string.Format(" alt=\"{0}\"", Img.alternateText));
           
            Img.background_color = txtBackground.Text;
            Img.width = !string.IsNullOrEmpty(txtWidth.Text)? Convert.ToInt32(txtWidth.Text):(int?)null ;
            if (chckLink.Checked)
            {
                Img.isLink = true;
                Img.link = link.Text;
            }
        }

        public string returnString(int? value)
        {
            if (value != null)
                return value.ToString();
            else
                return null;
        }
        public void SetTdStyleProperties(AdiImage img)
        {
            ptop.Text = returnString(img.pTop);
            pbottom.Text = returnString(img.pBottom);
            pleft.Text = returnString(img.pLeft);
            pright.Text = returnString(img.pRight);

            mtop.Text = returnString(img.mTop);
            mbottom.Text = returnString(img.mBottom);
            mleft.Text = returnString(img.mLeft);
            mright.Text = returnString(img.mRight);

            btop.Text = returnString(img.bTop);
            bbottom.Text = returnString(img.bBottom);
            bleft.Text = returnString(img.bLeft);
            bright.Text = returnString(img.bRight);

            txtBorderColor.Text = img.borderColor;
        }
        public string GetTdStyleProperties()
        {
            StringBuilder sb = new StringBuilder();

            //sb.Append(string.Format("background-color:#{0};", txtbgcolor.Text));
            //FontP.background_color = txtbgcolor.Text;

            if (!string.IsNullOrEmpty(ptop.Text))
            {
                sb.Append(string.Format("padding-top:{0}px;", ptop.Text));
                Img.pTop = Convert.ToInt16(ptop.Text);
            }
            if (!string.IsNullOrEmpty(pbottom.Text))
            {
                sb.Append(string.Format("padding-bottom:{0}px;", pbottom.Text));
                Img.pBottom = Convert.ToInt16(pbottom.Text);
            }

            if (!string.IsNullOrEmpty(pleft.Text))
            {
                sb.Append(string.Format("padding-left:{0}px;", pleft.Text));
                Img.pLeft = Convert.ToInt16(pleft.Text);
            }

            if (!string.IsNullOrEmpty(pright.Text))
            {
                sb.Append(string.Format("padding-right:{0}px;", pright.Text));
                Img.pRight = Convert.ToInt16(pright.Text);
            }

            if (!string.IsNullOrEmpty(mtop.Text))
            {
                sb.Append(string.Format("margin-top:{0}px;", mtop.Text));
                Img.mTop = Convert.ToInt16(mtop.Text);
            }
            if (!string.IsNullOrEmpty(mbottom.Text))
            {
                sb.Append(string.Format("margin-bottom:{0}px;", mbottom.Text));
                Img.mBottom = Convert.ToInt16(mbottom.Text);
            } if (!string.IsNullOrEmpty(mleft.Text))
            {
                sb.Append(string.Format("margin-left:{0}px;", mleft.Text));
                Img.mLeft = Convert.ToInt16(mleft.Text);
            } if (!string.IsNullOrEmpty(mright.Text))
            {
                sb.Append(string.Format("margin-right:{0}px;", mright.Text));
                Img.mRight = Convert.ToInt16(mright.Text);
            } if (!string.IsNullOrEmpty(bleft.Text))
            {
                sb.Append(string.Format("border-left:{0}px solid #{1};", bleft.Text, !string.IsNullOrEmpty(txtBorderColor.Text) ? txtBorderColor.Text : "000000"));
                Img.bLeft = Convert.ToInt16(bleft.Text);
            } if (!string.IsNullOrEmpty(bright.Text))
            {
                sb.Append(string.Format("border-right:{0}px solid #{1};", bright.Text, !string.IsNullOrEmpty(txtBorderColor.Text) ? txtBorderColor.Text : "000000"));
                Img.bRight = Convert.ToInt16(bright.Text);
            } if (!string.IsNullOrEmpty(btop.Text))
            {
                sb.Append(string.Format("border-top:{0}px solid #{1};", btop.Text, !string.IsNullOrEmpty(txtBorderColor.Text) ? txtBorderColor.Text : "000000"));
                Img.bTop = Convert.ToInt16(btop.Text);
            } if (!string.IsNullOrEmpty(bbottom.Text))
            {
                sb.Append(string.Format("border-bottom:{0}px solid #{1};", bbottom.Text, !string.IsNullOrEmpty(txtBorderColor.Text) ? txtBorderColor.Text : "000000"));
                Img.bBottom = Convert.ToInt16(bbottom.Text);

            }
            Img.borderColor = txtBorderColor.Text;
            return sb.ToString();
        }
       
        public void SetAlignmentValues(AdiImage img)
        {
            if (img.hAlign == "center")
                centerAlign.Checked = true;
            else if (img.hAlign == "left")
                leftAlign.Checked = true;
            else
                rightAlign.Checked = true;

            if (img.vAlign == "middle")
                valignMiddle.Checked = true;
            else if (img.vAlign == "Top")
                vAlignTop.Checked = true;
            else
                vAlignBottom.Checked = true;

        }
        public string GetAlignmentValues()
        {
            StringBuilder sbNew = new StringBuilder();
            if (!leftAlign.Checked && !centerAlign.Checked && !rightAlign.Checked)
            {
                sbNew.Append(string.Format("align=\"{0}\" ", "center"));
                Img.hAlign = "center";
            }
            else
            {
                sbNew.Append(string.Format("align=\"{0}\" ", leftAlign.Checked ? "left" : (centerAlign.Checked ? "center" : "right")));
                Img.hAlign = leftAlign.Checked ? "left" : (centerAlign.Checked ? "center" : "right");
            }
            if (!vAlignTop.Checked && !valignMiddle.Checked && !vAlignBottom.Checked)
            {
                sbNew.Append(string.Format("valign=\"{0}\" ", "middle"));
                Img.vAlign = "middle";
            }
            else
            {
                sbNew.Append(string.Format("valign=\"{0}\" ", vAlignTop.Checked ? "Top" : (valignMiddle.Checked ? "middle" : "bottom")));
                Img.vAlign = vAlignTop.Checked ? "Top" : (valignMiddle.Checked ? "middle" : "bottom");

            }
            return sbNew.ToString();
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
           if(openFileDialog1.ShowDialog()==DialogResult.OK)
           {
               string fileName = openFileDialog1.FileName;
               lblFileName.Text = openFileDialog1.SafeFileName;
               Img.imagePath = openFileDialog1.FileName;
           }
        }

        private void chckLink_CheckedChanged(object sender, EventArgs e)
        {
            if (chckLink.Checked)
                link.Enabled = true;
            else
                link.Enabled = false;
        }


    }
}
