﻿namespace HTML_MainApp.UserControls
{
    partial class ucImage
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.bbottom = new System.Windows.Forms.TextBox();
            this.bright = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.bleft = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btop = new System.Windows.Forms.TextBox();
            this.mbottom = new System.Windows.Forms.TextBox();
            this.mright = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.mleft = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.vAlignBottom = new System.Windows.Forms.RadioButton();
            this.rightAlign = new System.Windows.Forms.RadioButton();
            this.valignMiddle = new System.Windows.Forms.RadioButton();
            this.centerAlign = new System.Windows.Forms.RadioButton();
            this.vAlignTop = new System.Windows.Forms.RadioButton();
            this.leftAlign = new System.Windows.Forms.RadioButton();
            this.txtBorderColor = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.pbottom = new System.Windows.Forms.TextBox();
            this.pright = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pleft = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.ptop = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.mtop = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAlternateText = new System.Windows.Forms.TextBox();
            this.btnUpload = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.txtBackground = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtWidth = new System.Windows.Forms.TextBox();
            this.lblFileName = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.chckLink = new System.Windows.Forms.CheckBox();
            this.link = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 4;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.66667F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.33333F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.Controls.Add(this.bbottom, 3, 1);
            this.tableLayoutPanel4.Controls.Add(this.bright, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.label13, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label14, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.bleft, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label15, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.label16, 2, 1);
            this.tableLayoutPanel4.Controls.Add(this.btop, 1, 1);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(7, 19);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(114, 43);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // bbottom
            // 
            this.bbottom.Location = new System.Drawing.Point(83, 24);
            this.bbottom.Name = "bbottom";
            this.bbottom.Size = new System.Drawing.Size(27, 20);
            this.bbottom.TabIndex = 8;
            // 
            // bright
            // 
            this.bright.Location = new System.Drawing.Point(83, 3);
            this.bright.Name = "bright";
            this.bright.Size = new System.Drawing.Size(27, 20);
            this.bright.TabIndex = 7;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(13, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "L";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 21);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(14, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "T";
            // 
            // bleft
            // 
            this.bleft.Location = new System.Drawing.Point(30, 3);
            this.bleft.Name = "bleft";
            this.bleft.Size = new System.Drawing.Size(25, 20);
            this.bleft.TabIndex = 4;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(61, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(15, 13);
            this.label15.TabIndex = 5;
            this.label15.Text = "R";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(61, 21);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(14, 13);
            this.label16.TabIndex = 3;
            this.label16.Text = "B";
            // 
            // btop
            // 
            this.btop.Location = new System.Drawing.Point(30, 24);
            this.btop.Name = "btop";
            this.btop.Size = new System.Drawing.Size(25, 20);
            this.btop.TabIndex = 6;
            // 
            // mbottom
            // 
            this.mbottom.Location = new System.Drawing.Point(83, 24);
            this.mbottom.Name = "mbottom";
            this.mbottom.Size = new System.Drawing.Size(27, 20);
            this.mbottom.TabIndex = 8;
            // 
            // mright
            // 
            this.mright.Location = new System.Drawing.Point(83, 3);
            this.mright.Name = "mright";
            this.mright.Size = new System.Drawing.Size(27, 20);
            this.mright.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(13, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "L";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 21);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(14, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "T";
            // 
            // mleft
            // 
            this.mleft.Location = new System.Drawing.Point(30, 3);
            this.mleft.Name = "mleft";
            this.mleft.Size = new System.Drawing.Size(25, 20);
            this.mleft.TabIndex = 4;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(61, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(15, 13);
            this.label11.TabIndex = 5;
            this.label11.Text = "R";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 3;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.Controls.Add(this.rightAlign, 2, 0);
            this.tableLayoutPanel5.Controls.Add(this.centerAlign, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.leftAlign, 0, 0);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(6, 117);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(85, 32);
            this.tableLayoutPanel5.TabIndex = 25;
            // 
            // vAlignBottom
            // 
            this.vAlignBottom.Appearance = System.Windows.Forms.Appearance.Button;
            this.vAlignBottom.AutoSize = true;
            this.vAlignBottom.Location = new System.Drawing.Point(56, 3);
            this.vAlignBottom.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.vAlignBottom.Name = "vAlignBottom";
            this.vAlignBottom.Size = new System.Drawing.Size(24, 23);
            this.vAlignBottom.TabIndex = 2;
            this.vAlignBottom.Text = "B";
            this.vAlignBottom.UseVisualStyleBackColor = true;
            // 
            // rightAlign
            // 
            this.rightAlign.Appearance = System.Windows.Forms.Appearance.Button;
            this.rightAlign.AutoSize = true;
            this.rightAlign.Location = new System.Drawing.Point(59, 3);
            this.rightAlign.Name = "rightAlign";
            this.rightAlign.Size = new System.Drawing.Size(23, 23);
            this.rightAlign.TabIndex = 20;
            this.rightAlign.Text = "R";
            this.rightAlign.UseVisualStyleBackColor = true;
            // 
            // valignMiddle
            // 
            this.valignMiddle.Appearance = System.Windows.Forms.Appearance.Button;
            this.valignMiddle.AutoSize = true;
            this.valignMiddle.Checked = true;
            this.valignMiddle.Location = new System.Drawing.Point(31, 3);
            this.valignMiddle.Name = "valignMiddle";
            this.valignMiddle.Size = new System.Drawing.Size(22, 23);
            this.valignMiddle.TabIndex = 1;
            this.valignMiddle.TabStop = true;
            this.valignMiddle.Text = "M";
            this.valignMiddle.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.valignMiddle.UseVisualStyleBackColor = true;
            // 
            // centerAlign
            // 
            this.centerAlign.Appearance = System.Windows.Forms.Appearance.Button;
            this.centerAlign.AutoSize = true;
            this.centerAlign.Checked = true;
            this.centerAlign.Location = new System.Drawing.Point(31, 3);
            this.centerAlign.Name = "centerAlign";
            this.centerAlign.Size = new System.Drawing.Size(22, 23);
            this.centerAlign.TabIndex = 19;
            this.centerAlign.TabStop = true;
            this.centerAlign.Text = "M";
            this.centerAlign.UseVisualStyleBackColor = true;
            // 
            // vAlignTop
            // 
            this.vAlignTop.Appearance = System.Windows.Forms.Appearance.Button;
            this.vAlignTop.AutoSize = true;
            this.vAlignTop.Location = new System.Drawing.Point(3, 3);
            this.vAlignTop.Name = "vAlignTop";
            this.vAlignTop.Size = new System.Drawing.Size(22, 23);
            this.vAlignTop.TabIndex = 0;
            this.vAlignTop.Text = "T";
            this.vAlignTop.UseVisualStyleBackColor = true;
            // 
            // leftAlign
            // 
            this.leftAlign.Appearance = System.Windows.Forms.Appearance.Button;
            this.leftAlign.AutoSize = true;
            this.leftAlign.Location = new System.Drawing.Point(3, 3);
            this.leftAlign.Name = "leftAlign";
            this.leftAlign.Size = new System.Drawing.Size(22, 23);
            this.leftAlign.TabIndex = 18;
            this.leftAlign.Text = "L";
            this.leftAlign.UseVisualStyleBackColor = true;
            // 
            // txtBorderColor
            // 
            this.txtBorderColor.Location = new System.Drawing.Point(79, 3);
            this.txtBorderColor.Name = "txtBorderColor";
            this.txtBorderColor.Size = new System.Drawing.Size(67, 20);
            this.txtBorderColor.TabIndex = 2;
            this.txtBorderColor.Text = "ffffff";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(3, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(38, 13);
            this.label17.TabIndex = 3;
            this.label17.Text = "Border";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(61, 21);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(14, 13);
            this.label12.TabIndex = 3;
            this.label12.Text = "B";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tableLayoutPanel2);
            this.groupBox2.Location = new System.Drawing.Point(251, 83);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(124, 72);
            this.groupBox2.TabIndex = 22;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Padding";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.Controls.Add(this.pbottom, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.pright, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label7, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.pleft, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label6, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label8, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.ptop, 1, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(4, 19);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(114, 43);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // pbottom
            // 
            this.pbottom.Location = new System.Drawing.Point(87, 24);
            this.pbottom.Name = "pbottom";
            this.pbottom.Size = new System.Drawing.Size(24, 20);
            this.pbottom.TabIndex = 8;
            // 
            // pright
            // 
            this.pright.Location = new System.Drawing.Point(87, 3);
            this.pright.Name = "pright";
            this.pright.Size = new System.Drawing.Size(24, 20);
            this.pright.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "L";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(14, 13);
            this.label7.TabIndex = 2;
            this.label7.Text = "T";
            // 
            // pleft
            // 
            this.pleft.Location = new System.Drawing.Point(31, 3);
            this.pleft.Name = "pleft";
            this.pleft.Size = new System.Drawing.Size(22, 20);
            this.pleft.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(59, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(15, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "R";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(59, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(14, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "B";
            // 
            // ptop
            // 
            this.ptop.Location = new System.Drawing.Point(31, 24);
            this.ptop.Name = "ptop";
            this.ptop.Size = new System.Drawing.Size(22, 20);
            this.ptop.TabIndex = 6;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tableLayoutPanel3);
            this.groupBox3.Location = new System.Drawing.Point(381, 83);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(124, 72);
            this.groupBox3.TabIndex = 23;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Margin";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 4;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.66667F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.33333F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.Controls.Add(this.mbottom, 3, 1);
            this.tableLayoutPanel3.Controls.Add(this.mright, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.label9, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label10, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.mleft, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label11, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.label12, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.mtop, 1, 1);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(7, 19);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(114, 43);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // mtop
            // 
            this.mtop.Location = new System.Drawing.Point(30, 24);
            this.mtop.Name = "mtop";
            this.mtop.Size = new System.Drawing.Size(25, 20);
            this.mtop.TabIndex = 6;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tableLayoutPanel4);
            this.groupBox4.Location = new System.Drawing.Point(511, 83);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(124, 72);
            this.groupBox4.TabIndex = 24;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Border";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "Enter Image";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel1);
            this.groupBox1.Location = new System.Drawing.Point(93, 83);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(156, 72);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "properties";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Controls.Add(this.txtBorderColor, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label17, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtAlternateText, 1, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(4, 19);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(152, 47);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "AlternateText";
            // 
            // txtAlternateText
            // 
            this.txtAlternateText.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtAlternateText.Location = new System.Drawing.Point(79, 26);
            this.txtAlternateText.Name = "txtAlternateText";
            this.txtAlternateText.Size = new System.Drawing.Size(70, 20);
            this.txtAlternateText.TabIndex = 6;
            // 
            // btnUpload
            // 
            this.btnUpload.Location = new System.Drawing.Point(12, 24);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(75, 23);
            this.btnUpload.TabIndex = 27;
            this.btnUpload.Text = "Upload";
            this.btnUpload.UseVisualStyleBackColor = true;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.tableLayoutPanel7);
            this.groupBox6.Location = new System.Drawing.Point(479, 5);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(156, 72);
            this.groupBox6.TabIndex = 24;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Properties";
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel7.Controls.Add(this.txtBackground, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.txtWidth, 1, 1);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(4, 19);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(152, 43);
            this.tableLayoutPanel7.TabIndex = 0;
            // 
            // txtBackground
            // 
            this.txtBackground.Location = new System.Drawing.Point(79, 3);
            this.txtBackground.Name = "txtBackground";
            this.txtBackground.Size = new System.Drawing.Size(67, 20);
            this.txtBackground.TabIndex = 2;
            this.txtBackground.Text = "ffffff";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "width";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "background";
            // 
            // txtWidth
            // 
            this.txtWidth.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtWidth.Location = new System.Drawing.Point(79, 24);
            this.txtWidth.Name = "txtWidth";
            this.txtWidth.Size = new System.Drawing.Size(70, 20);
            this.txtWidth.TabIndex = 6;
            // 
            // lblFileName
            // 
            this.lblFileName.AutoSize = true;
            this.lblFileName.ForeColor = System.Drawing.Color.Blue;
            this.lblFileName.Location = new System.Drawing.Point(97, 28);
            this.lblFileName.Name = "lblFileName";
            this.lblFileName.Size = new System.Drawing.Size(0, 13);
            this.lblFileName.TabIndex = 28;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.tableLayoutPanel6);
            this.groupBox5.Location = new System.Drawing.Point(150, 48);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(323, 36);
            this.groupBox5.TabIndex = 29;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Link";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 75F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.Controls.Add(this.chckLink, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.link, 1, 0);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(35, 11);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(284, 25);
            this.tableLayoutPanel6.TabIndex = 30;
            // 
            // chckLink
            // 
            this.chckLink.AutoSize = true;
            this.chckLink.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.chckLink.Location = new System.Drawing.Point(3, 3);
            this.chckLink.Name = "chckLink";
            this.chckLink.Size = new System.Drawing.Size(60, 17);
            this.chckLink.TabIndex = 0;
            this.chckLink.Text = "IsLink?";
            this.chckLink.UseVisualStyleBackColor = true;
            this.chckLink.CheckedChanged += new System.EventHandler(this.chckLink_CheckedChanged);
            // 
            // link
            // 
            this.link.Enabled = false;
            this.link.Location = new System.Drawing.Point(78, 3);
            this.link.Name = "link";
            this.link.Size = new System.Drawing.Size(206, 20);
            this.link.TabIndex = 1;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 3;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel8.Controls.Add(this.valignMiddle, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.vAlignTop, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.vAlignBottom, 2, 0);
            this.tableLayoutPanel8.Location = new System.Drawing.Point(6, 83);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(85, 33);
            this.tableLayoutPanel8.TabIndex = 30;
            // 
            // ucImage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel8);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.lblFileName);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.btnUpload);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tableLayoutPanel5);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.label1);
            this.Name = "ucImage";
            this.Size = new System.Drawing.Size(643, 161);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.TextBox bbottom;
        private System.Windows.Forms.TextBox bright;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox bleft;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox btop;
        private System.Windows.Forms.TextBox mbottom;
        private System.Windows.Forms.TextBox mright;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox mleft;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.RadioButton rightAlign;
        private System.Windows.Forms.RadioButton centerAlign;
        private System.Windows.Forms.RadioButton leftAlign;
        private System.Windows.Forms.TextBox txtBorderColor;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.RadioButton vAlignBottom;
        private System.Windows.Forms.RadioButton valignMiddle;
        private System.Windows.Forms.RadioButton vAlignTop;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TextBox pbottom;
        private System.Windows.Forms.TextBox pright;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox pleft;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox ptop;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TextBox mtop;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAlternateText;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TextBox txtBackground;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtWidth;
        private System.Windows.Forms.Label lblFileName;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.CheckBox chckLink;
        private System.Windows.Forms.TextBox link;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;

    }
}
