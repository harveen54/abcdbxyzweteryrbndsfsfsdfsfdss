﻿using HTML_MainApp.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HTML_MainApp.Forms
{
    public partial class Add_Spacer : Form
    {
        public Add_Spacer()
        {
            InitializeComponent();
        }

        public Add_Spacer(AdiSpacer spc)
        {
            InitializeComponent();
            txtBgColor.Text = spc.BgColor;
            txtHeight.Text = spc.Height.ToString();
            txtLink.Text = spc.Link;
            btnAdd.Text = "Update";
        }

        private AdiSpacer _spc;

        public AdiSpacer spc
        {
            get { return _spc; }
            set { _spc = value; }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtHeight.Text) && ValidateFields.CheckIfValueIsNumeric(txtHeight.Text))
            {
                spc = new AdiSpacer();


                spc.BgColor = !string.IsNullOrEmpty(txtBgColor.Text) ? txtBgColor.Text : "ffffff";
                spc.Height = !string.IsNullOrEmpty(txtHeight.Text) ? Convert.ToInt32(txtHeight.Text) : 0;
                spc.Link = !string.IsNullOrEmpty(txtLink.Text) ? txtLink.Text : null;
                if (btnAdd.Text == "Add")
                    spc.isAdded = true;
                else if (btnAdd.Text == "Update")
                    spc.isUpdated = true;
                this.Hide();
            }
            else
            {
                MessageBox.Show("Please enter correct Height");
            }
        }
    }
}
