﻿namespace HTML_MainApp.Forms
{
    partial class AddImage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ucAddImage = new HTML_MainApp.UserControls.ucImage();
            this.brnAdd = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ucAddImage
            // 
       
            this.ucAddImage.Location = new System.Drawing.Point(12, 12);
            this.ucAddImage.Name = "ucAddImage";
            this.ucAddImage.Size = new System.Drawing.Size(643, 161);
            this.ucAddImage.TabIndex = 0;
            // 
            // brnAdd
            // 
            this.brnAdd.Location = new System.Drawing.Point(294, 179);
            this.brnAdd.Name = "brnAdd";
            this.brnAdd.Size = new System.Drawing.Size(75, 23);
            this.brnAdd.TabIndex = 1;
            this.brnAdd.Text = "Add";
            this.brnAdd.UseVisualStyleBackColor = true;
            this.brnAdd.Click += new System.EventHandler(this.brnAdd_Click);
            // 
            // AddImage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(651, 262);
            this.Controls.Add(this.brnAdd);
            this.Controls.Add(this.ucAddImage);
            this.Name = "AddImage";
            this.Text = "AddImage";
            this.ResumeLayout(false);

        }

        #endregion

        private UserControls.ucImage ucAddImage;
        private System.Windows.Forms.Button brnAdd;
    }
}