﻿using HTML_MainApp.Classes;
using HTML_MainApp.UserControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HTML_MainApp.Forms
{
    public partial class AddText_1xi : Form
    {
        public bool IsAdded;
        public AddText_1xi()
        {
            InitializeComponent();
        }

        public AddText_1xi(AdiText_1xi text)
        {
            InitializeComponent();
            InitializeControls(text.elements,text);

            //ucAddText.SetValueOfStyle(text.fontProperties);
            //ucAddText.SetText(text.text);
            //ucAddText.SetAlignmentValues(text.fontProperties);
            //btnAdd.Text = "Update";
          
        }

        public void InitializeControls(int n,AdiText_1xi text)
        {
            ucText[] controls = new ucText[n];

            for (int i = 0; i < n; i++)
            {
                controls[i] = new ucText();
            }

            int y = 0;
            for (int i = 0; i < n; i++)
            {
                if (i != 0)
                    y += i + 300;

                controls[i].Location = new Point(i, y);
                controls[i].SetAlignmentValues(text.listAdiText[i].fontProperties);
                controls[i].SetValueOfStyle(text.listAdiText[i].fontProperties);
                controls[i].SetText(text.listAdiText[i].text);
                this.panel1.Controls.Add(controls[i]);
            }
            btnAdd.Text = "Update";
            txtNumber.Text =  n.ToString();
            txtNumber.Enabled = false;
            btnGo.Enabled = false;
            Adi = text;
            Adi.controls = controls;
        }

        private AdiText_1xi _adi;

        public AdiText_1xi Adi
        {
            get { return _adi; }
            set { _adi = value; }
        }


        private void btnGo_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtNumber.Text))
            {
                int n = Convert.ToInt32(txtNumber.Text);

                ucText[] controls = new ucText[n];
                for (int i = 0; i < n; i++)
                {
                    controls[i] = new ucText();

                    // controls[i].SetTextBoxValue("some value to display in text");
                    //  controls[i].SetLabelValue(i.ToString());
                    // Now if you write controls[i].getTextBoxValue() it will return "some value to display in text" and controls[i].getLabelValue() will return "some value to display in label". These value will also be displayed in the user control.
                }

                // This adds the controls to the form (you will need to specify thier co-ordinates etc. first)
                int y = 0;
                for (int i = 0; i < n; i++)
                {
                    if (i != 0)
                        y += i + 300;

                    controls[i].Location = new Point(i, y);
                    this.panel1.Controls.Add(controls[i]);
                }
                Adi = new AdiText_1xi()
                {
                    controls = controls,
                    elements = n
                };

            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            if (btnAdd.Text == "Update")
            {

            }
            else
                IsAdded = true;
            int n = Convert.ToInt32(txtNumber.Text);
            int flag = 0;
            AdiText[] aditext = new AdiText[n];
            for (int i = 0; i < n; i++)
            {
                var ucAddText = Adi.controls[i];
                Adi.controls[i].ValidateForm();
                if (!ucAddText.HasErrors)
                {
                    var classAdi = new AdiText();
                    classAdi.style = ucAddText.GetValueOfStyle();
                    classAdi.text = ucAddText.GetText();
                    classAdi.alignment = ucAddText.GetAlignmentValues();
                    classAdi.fontProperties = ucAddText.FontP;
                    aditext[i] = classAdi;
                }

                else
                {
                    flag = 1;
                }
            }
           
            if (flag == 1)
                MessageBox.Show("Please correct the fields in red");
            else
            {
                Adi.listAdiText = aditext;
                Adi.isSet = true;
                this.Hide();
            }

        }

    }
}

