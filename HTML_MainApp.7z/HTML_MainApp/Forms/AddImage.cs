﻿using HTML_MainApp.Classes;
using HTML_MainApp.UserControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HTML_MainApp.Forms
{
    public partial class AddImage : Form
    {
        public bool IsAdded;
        private AdiImage _adi;

        public AdiImage Adi
        {
            get { return _adi; }
            set { _adi = value; }
        }
        public AddImage()
        {
            InitializeComponent();
        }
        public AddImage(AdiImage img)
        {
            InitializeComponent();
            brnAdd.Text = "Update";
            ucAddImage.SetAlignmentValues(img);
            ucAddImage.SetImageProperties(img);
            ucAddImage.SetTdStyleProperties(img);
        }

        private void brnAdd_Click(object sender, EventArgs e)
        {
            IsAdded = true;
          //  Adi = new AdiImage();
            ucAddImage.ValidateField();
            if (!ucAddImage.HasErrors)
            {
                ucAddImage.ValidateForm();
                if (!ucAddImage.HasErrors)
                {

                    Adi = ucAddImage.Img;
                    Adi.style = ucAddImage.GetTdStyleProperties();
                    ucAddImage.GetImageProperties();
                    // Adi.alink= 
                    Adi.alignment = ucAddImage.GetAlignmentValues();
                    if (Adi.isLink)
                    {
                        Adi.alink = string.Format(@"<a href=""{0}"" target=""_blank"" >", Adi.link);
                    }
                    else
                        Adi.alink = "";
                    if (brnAdd.Text == "Add")
                        Adi.isSet = true;
                    else if (brnAdd.Text == "Update")
                        Adi.isUpdated = true;
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Please correct the fields marked in Red");
                }
            }

            else
            {
                MessageBox.Show("Please select an Image File First");
            }
        }
    }
}
