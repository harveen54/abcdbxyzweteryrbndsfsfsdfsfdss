﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HTML_MainApp
{
    public partial class DynamicTd : UserControl
    {
        public DynamicTd()
        {
            InitializeComponent();
        }

        public string GetTextBoxValue()
        {
            return this.textBox1.Text;
        }

        public string GetLabelValue()
        {
            return this.label1.Text;
        }

        public void SetTextBoxValue(string newText)
        {
            this.textBox1.Text = newText;
        }

        public void SetLabelValue(string newText)
        {
            this.label1.Text += newText;
        }
    }
}
