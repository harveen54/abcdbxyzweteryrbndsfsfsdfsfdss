﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HTML_MainApp
{
    public class Adi_Responsive_Text_1Xi
    {
        public int elements;
        public DynamicTd[] controls;
        public bool isSet;
        public string HTML;
    }
}
