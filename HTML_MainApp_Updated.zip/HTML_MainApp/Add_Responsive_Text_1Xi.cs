﻿using HTML_MainApp.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HTML_MainApp
{
    public partial class Add_Responsive_Text_1Xi : Form
    {
        public Adi_Responsive_Text_1Xi adiResponsive;
        public Add_Responsive_Text_1Xi()
        {
            InitializeComponent();
           
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtNumber.Text))
            {
                int n = Convert.ToInt32(txtNumber.Text);
                //TextBox[] textBoxes = new TextBox[n];
                //Label[] labels = new Label[n];

                //for (int i = 0; i < n; i++)
                //{
                //    textBoxes[i] = new TextBox()
                //        {
                //            Name="txtTr("+i+")"
                //        };
                //    // Here you can modify the value of the textbox which is at textBoxes[i]

                //    labels[i] = new Label()
                //        {
                //            Text="Enter value of tr-"+i
                //        };
                //    // Here you can modify the value of the label which is at labels[i]
                //}

                //// This adds the controls to the form (you will need to specify thier co-ordinates etc. first)
                //for (int i = 0; i < n; i++)
                //{
                //    this.panel1.Controls.Add(textBoxes[i]);
                //    this.panel1.Controls.Add(labels[i]);
                //}

                DynamicTd[] controls = new DynamicTd[n];
                for (int i = 0; i < n; i++)
                {
                    controls[i] = new DynamicTd();

                   // controls[i].SetTextBoxValue("some value to display in text");
                    controls[i].SetLabelValue(i.ToString());
                    // Now if you write controls[i].getTextBoxValue() it will return "some value to display in text" and controls[i].getLabelValue() will return "some value to display in label". These value will also be displayed in the user control.
                }

                // This adds the controls to the form (you will need to specify thier co-ordinates etc. first)
                int y = 0;
                for (int i = 0; i < n; i++)
                {
                    if(i!=0)
                    y += i +76;
                    
                    controls[i].Location = new Point(i, y);
                    this.panel1.Controls.Add(controls[i]);
                }
                adiResponsive = new Adi_Responsive_Text_1Xi()
                {
                     controls=controls,
                      elements=n
                }
                    ;
            
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            adiResponsive.isSet = true;
        }
    }
}
