﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HTML_MainApp.Classes
{
    public class AdiButton
    {
        public string link;
        public string source;
        public string HTML;
        public bool isAdded;
        public bool isUpdated;
        public string fullName;
    }
}
