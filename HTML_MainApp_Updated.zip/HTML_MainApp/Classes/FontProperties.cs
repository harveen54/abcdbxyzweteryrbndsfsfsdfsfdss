﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace HTML_MainApp.Classes
{
    [Serializable]
    public class FontProperties : IXmlSerializable
    {
        public bool bold;
        public bool italic;
        public bool underline;
        public string font_family;
        public int font_size;
        public string color;
        public string background_color;
        public int? pTop;
        public int? pBottom;
        public int? pLeft;
        public int? pRight;
        public int? mTop;
        public int? mBottom;
        public int? mLeft;
        public int? mRight;
        public int? bTop;
        public int? bBottom;
        public int? bLeft;
        public int? bRight;
        public string borderColor;
        public string hAlign;
        public string vAlign;

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            //reader.MoveToContent();
            //// Name = reader.GetAttribute("Name");
            //Boolean isEmptyElement = reader.IsEmptyElement; // (1)
            //reader.ReadStartElement();
            //if (!isEmptyElement) // (1)
            //{


    

                bold = reader.ReadElementString("bold").ToString() == "bold" ? true : false;
                italic = reader.ReadElementString("italic").ToString() == "true" ? true : false;
                underline = reader.ReadElementString("underline").ToString() == "true" ? true : false;



                font_family = reader.ReadElementString("font_family").ToString();
                font_size = Convert.ToInt32(reader.ReadElementString("font_size").ToString());
                color = reader.ReadElementString("color").ToString();
                background_color = reader.ReadElementString("background_color");
                borderColor = reader.ReadElementString("borderColor").ToString();

                hAlign = reader.ReadElementString("hAlign").ToString();
                vAlign = reader.ReadElementString("vAlign").ToString();
                
                string btop = reader.ReadElementString("bTop");
                string mtop = reader.ReadElementString("mTop");

                string ptop = reader.ReadElementString("pTop");
                string bbottom = reader.ReadElementString("bBottom");
                string mbottom = reader.ReadElementString("mBottom");

                string pbottom = reader.ReadElementString("pBottom");
                string bleft = reader.ReadElementString("bLeft");
                string mleft = reader.ReadElementString("mLeft");

                string pleft = reader.ReadElementString("pLeft");
                string bright = reader.ReadElementString("bRight");
                string mright = reader.ReadElementString("mRight");

                string pright = reader.ReadElementString("pRight");

                pTop = !string.IsNullOrEmpty(ptop) ? Convert.ToInt32(ptop.ToString()) : (int?)null;
                bTop = !string.IsNullOrEmpty(btop) ? Convert.ToInt32(btop.ToString()) : (int?)null;
                mTop = !string.IsNullOrEmpty(mtop) ? Convert.ToInt32(mtop.ToString()) : (int?)null;
                pBottom = !string.IsNullOrEmpty(pbottom) ? Convert.ToInt32(pbottom.ToString()) : (int?)null;
                bBottom = !string.IsNullOrEmpty(bbottom) ? Convert.ToInt32(bbottom.ToString()) : (int?)null;
                mBottom = !string.IsNullOrEmpty(mbottom) ? Convert.ToInt32(mbottom.ToString()) : (int?)null;
                pLeft = !string.IsNullOrEmpty(pleft) ? Convert.ToInt32(pleft.ToString()) : (int?)null;
                bLeft = !string.IsNullOrEmpty(mleft) ? Convert.ToInt32(mleft.ToString()) : (int?)null;
                mLeft = !string.IsNullOrEmpty(bleft) ? Convert.ToInt32(bleft.ToString()) : (int?)null;
                pRight = !string.IsNullOrEmpty(pright) ? Convert.ToInt32(pright.ToString()) : (int?)null;
                mRight = !string.IsNullOrEmpty(mright) ? Convert.ToInt32(mright.ToString()) : (int?)null;
                bRight = !string.IsNullOrEmpty(bright) ? Convert.ToInt32(bright.ToString()) : (int?)null;




                //reader.ReadEndElement();
            //}

        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            //  writer.WriteStartElement("XmlSerializable");

         
                writer.WriteElementString("bold",
                       bold.ToString());
            writer.WriteElementString("italic",
                      italic.ToString());
            writer.WriteElementString("underline",
                      underline.ToString());

            writer.WriteElementString("font_family",
                        font_family);
            writer.WriteElementString("font_size",
                       font_size.ToString());
            writer.WriteElementString("color",
                       color);
            writer.WriteElementString("background_color",
                       background_color);

             writer.WriteElementString("borderColor",
                       font_size.ToString());
            writer.WriteElementString("hAlign",
                       color);
            writer.WriteElementString("vAlign",
                       background_color);


            if (bTop != null)
                writer.WriteElementString("bTop",
                         bTop.ToString());
            else
                writer.WriteElementString("bTop",
                        null);

            if (mTop != null)
                writer.WriteElementString("mTop",
                         mTop.ToString());
            else
                writer.WriteElementString("mTop",
                        null);
            if (pTop != null)
                writer.WriteElementString("pTop",
                         pTop.ToString());
            else
                writer.WriteElementString("pTop",
                        null);

            if (bBottom != null)
                writer.WriteElementString("bBottom",
                         bBottom.ToString());
            else
                writer.WriteElementString("bBottom",
                        null);
            if (mBottom != null)
                writer.WriteElementString("mBottom",
                         mBottom.ToString());
            else
                writer.WriteElementString("mBottom",
                        null);


            if (pBottom != null)
                writer.WriteElementString("pBottom",
                         pBottom.ToString());
            else
                writer.WriteElementString("pBottom",
                        null);



            if (bLeft != null)
                writer.WriteElementString("bLeft",
                         bLeft.ToString());
            else
                writer.WriteElementString("bLeft",
                        null);
            if (mLeft != null)
                writer.WriteElementString("mLeft",
                         mLeft.ToString());
            else
                writer.WriteElementString("mLeft",
                        null);
            if (pLeft != null)
                writer.WriteElementString("pLeft",
                         pLeft.ToString());
            else
                writer.WriteElementString("pLeft",
                        null);




            if (bRight != null)
                writer.WriteElementString("bRight",
                         bRight.ToString());
            else
                writer.WriteElementString("bRight",
                        null);

            if (mRight != null)
                writer.WriteElementString("mRight",
                         mRight.ToString());
            else
                writer.WriteElementString("mRight",
                        null);
            if (pRight != null)
                writer.WriteElementString("pRight",
                         pRight.ToString());

            else
                writer.WriteElementString("pRight",
                        null);



      
            //writer.WriteEndElement();
        }


    }
}
