﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HTML_MainApp.Classes
{
    static class ValidateFields
    {
        public static bool CheckIfValueIsNumeric(string text)
        {
            try
            {
                if (string.IsNullOrEmpty(text))
                    return true;
                Convert.ToInt32(text);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
