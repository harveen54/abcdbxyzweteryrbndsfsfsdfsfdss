﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace HTML_MainApp.Classes
{
    [Serializable]
    public class AdiSpacer : IXmlSerializable
    {
        public string BgColor;
        public int Height;
        public string HTML;
        public string Link;
        public bool isAdded;
        public bool isUpdated;


        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            reader.MoveToContent();
            // Name = reader.GetAttribute("Name");
            Boolean isEmptyElement = reader.IsEmptyElement; // (1)
            reader.ReadStartElement();
            if (!isEmptyElement) // (1)
            {
              


                BgColor = reader.ReadElementString("BgColor").ToString();
                Height = Convert.ToInt32( reader.ReadElementString("Height").ToString());
                HTML = reader.ReadElementString("HTML").ToString();
                Link = reader.ReadElementString("Link");
                isAdded = reader.ReadElementString("isAdded").ToString() == "true" ? true : false;
                isUpdated = reader.ReadElementString("isUpdated").ToString() == "true" ? true : false;
                
            }

        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {

            writer.WriteElementString("BgColor",
                    BgColor);

            writer.WriteElementString("Height",
                      Height.ToString());


            writer.WriteElementString("HTML",
                     HTML);
            writer.WriteElementString("Link",
                      Link);

            writer.WriteElementString("isAdded",
                       isAdded.ToString());

            writer.WriteElementString("isUpdated",
                    isUpdated.ToString());


           
          
        }
    }
}
