﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace HTML_MainApp.Classes
{
    [Serializable]
    public class AdiText : IXmlSerializable
    {
        public string bgColor;
        public string HTML;

        public string style;
        public string alignment;
        public string text;
        public FontProperties fontProperties;
        public bool isSet;
        public bool isUpdated;


        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            reader.MoveToContent();

            Boolean isEmptyElement = reader.IsEmptyElement; // (1)
            reader.ReadStartElement();
            if (!isEmptyElement) // (1)
            {



                bgColor = reader.ReadElementString("bgColor").ToString();
                HTML = reader.ReadElementString("HTML").ToString();
                style = reader.ReadElementString("style").ToString();
                alignment = reader.ReadElementString("alignment");
                text = reader.ReadElementString("text").ToString();

               isSet = reader.ReadElementString("isSet").ToString() == "true" ? true : false;
                isUpdated = reader.ReadElementString("isUpdated").ToString() == "true" ? true : false;

                fontProperties = new FontProperties();
                
                fontProperties.ReadXml(reader);
                //reader.ReadEndElement();
            }

        }

        public void ReadXmlI(System.Xml.XmlReader reader)
        {
            bgColor = reader.ReadElementString("bgColor").ToString();
            HTML = reader.ReadElementString("HTML").ToString();
            style = reader.ReadElementString("style").ToString();
            alignment = reader.ReadElementString("alignment");
            text = reader.ReadElementString("text").ToString();
            isSet = reader.ReadElementString("isSet").ToString() == "true" ? true : false;
            isUpdated = reader.ReadElementString("isUpdated").ToString() == "true" ? true : false;
            fontProperties = new FontProperties();
            fontProperties.ReadXml(reader);
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {



         
                writer.WriteElementString("bgColor",
                    bgColor);

            writer.WriteElementString("HTML",
                      HTML);


            writer.WriteElementString("style",
                     style);


            
            writer.WriteElementString("alignment",
                       alignment);
            writer.WriteElementString("text",
                       text);
           
            writer.WriteElementString("isSet",
                       isSet.ToString());
            writer.WriteElementString("isUpdated",
                       isUpdated.ToString());

            fontProperties.GetSchema();
            fontProperties.WriteXml(writer);

        }
    }

}
