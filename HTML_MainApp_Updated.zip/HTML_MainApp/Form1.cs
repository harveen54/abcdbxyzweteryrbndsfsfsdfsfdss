﻿using HTML_MainApp.Classes;
using HTML_MainApp.Forms;
using HTML_MainApp.UserControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HTML_MainApp
{
    public partial class Form1 : Form
    {
        private List<object> _list;

        public List<object> List
        {
            get { return _list; }
            set { _list = value; }
        }


        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // DataGridViewRow row = new DataGridViewRow();
            List = new List<object>();
            //if (ValidateInput())
            {
                string bgcolor = string.IsNullOrEmpty(txtColor.Text) ? "#000000" : "#" + txtColor.Text;

                if (cmbType.SelectedItem.ToString() == "Image")
                {
                    string imagePath = btnOpenFile.Visible ? openFileDialog1.FileName : null;
                    //this.dataGridView1.Rows.Add(cmbType.SelectedItem, imagePath, bgcolor, null, null);

                    AddImage add = new AddImage();
                    add.ShowDialog();
                    if (add != null && add.Adi != null)
                    {
                        //if (add.IsAdded)
                        {
                            this.dataGridView1.Rows.Add(cmbType.SelectedItem, add.Adi, add.Adi.Path, add.Adi.mTop, text, add.Adi);
                            // List.Add(add.Adi);
                        }
                        add.Close();
                        add.Dispose();
                        this.Focus();
                    }
                }
                if (cmbType.SelectedItem.ToString() == "Text")
                {
                    //string text = generic.Text == "Enter Text" ? txtgeneric.Text : null;
                    //this.dataGridView1.Rows.Add(cmbType.SelectedItem, null, bgcolor, text, null);
                    AddText add = new AddText();
                    add.ShowDialog();

                    if(add.IsAdded)
                    {
                        this.dataGridView1.Rows.Add(cmbType.SelectedItem,add.Adi.style, add.Adi.text, add.Adi.alignment, text,add.Adi);
                       // List.Add(add.Adi);
                    }
                    add.Close();
                    add.Dispose();
                    this.Focus();
                }
                if (cmbType.SelectedItem.ToString() == "Spacer")
                {
                    string spacerHeight = generic.Text == "Height of Spacer" ? txtgeneric.Text : null;
                    this.dataGridView1.Rows.Add(cmbType.SelectedItem, null, bgcolor, null, spacerHeight);
                }

                if (cmbType.SelectedItem.ToString() == "Responsive 1X2")
                {
                    openFileDialog1.Multiselect = true;
                    if (openFileDialog1.FileNames.Count() != 0)
                    {
                        StringBuilder sb = new StringBuilder();

                        for (int i = 0; i < openFileDialog1.FileNames.Count(); i++)
                        {
                            if (i == 0)
                                sb.Append(openFileDialog1.FileNames[i]);
                            else
                                sb.Append("," + openFileDialog1.FileNames[i]);

                        }
                        this.dataGridView1.Rows.Add(cmbType.SelectedItem, sb.ToString(), bgcolor, null, null);

                    }

                }
                if (cmbType.SelectedItem.ToString() == "Responsive 1Xi Text")
                {
                    //Add_Responsive_Text_1Xi add = new Add_Responsive_Text_1Xi();
                    //add.ShowDialog();

                    //if (add.adiResponsive.isSet)
                    //    this.dataGridView1.Rows.Add(cmbType.SelectedItem, add.adiResponsive, bgcolor, null, null);
                    //add.Close();
                    AddText_1xi add = new AddText_1xi();
                    add.ShowDialog();
                    if (add.IsAdded)
                    {
                        this.dataGridView1.Rows.Add(cmbType.SelectedItem, add.Adi, add.Adi, add.Adi, text, add.Adi);
                 
                    }
                }
            }
        }

        private void moveUp()
        {
            if (dataGridView1.RowCount > 0)
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    int rowCount = dataGridView1.Rows.Count;
                    int index = dataGridView1.SelectedCells[0].OwningRow.Index;

                    if (index == 0)
                    {
                        return;
                    }
                    DataGridViewRowCollection rows = dataGridView1.Rows;

                    // remove the previous row and add it behind the selected row.
                    DataGridViewRow prevRow = rows[index - 1];
                    rows.Remove(prevRow);
                    prevRow.Frozen = false;
                    rows.Insert(index, prevRow);
                    dataGridView1.ClearSelection();
                    dataGridView1.Rows[index - 1].Selected = true;
                }
            }
        }

        private void moveDown()
        {
            if (dataGridView1.RowCount > 0)
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    int rowCount = dataGridView1.Rows.Count;
                    int index = dataGridView1.SelectedCells[0].OwningRow.Index;

                    if (index == (rowCount - 2)) // include the header row
                    {
                        return;
                    }
                    DataGridViewRowCollection rows = dataGridView1.Rows;

                    // remove the next row and add it in front of the selected row.
                    DataGridViewRow nextRow = rows[index + 1];
                    rows.Remove(nextRow);
                    nextRow.Frozen = false;
                    rows.Insert(index, nextRow);
                    dataGridView1.ClearSelection();
                    dataGridView1.Rows[index + 1].Selected = true;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            moveUp();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            moveDown();
        }

        private void btnCreateHTML_Click(object sender, EventArgs e)
        {
              List<object> list=new List<object>();

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.Cells["Type"].Value.ToString() == "Image")
                {
//                    AdiImage img = new AdiImage();
//                    img.bgColor = row.Cells["BgColor"].Value != null ? row.Cells["BgColor"].Value.ToString() : null;
//                    img.imagePath = row.Cells["ImagePath"].Value != null ? row.Cells["ImagePath"].Value.ToString() : null;

//                    #region HTML
//                    img.HTML = String.Format(@"      <tr>
//            <td>
//                <table cellpadding=""0"" cellspacing=""0"" border=""0"" width=""100%"">
//                    <!-- body part 1 starts -->
//                    <tr>
//                        <td>
//                            <table border=""0"" cellpadding=""0"" cellspacing=""0"" width=""100%"">
//                                <tr>
//                                    <td align=""center"" valign=""top"" style=""background-color: {0};"" bgcolor=""{0}"">
//                                        <table border=""0"" width=""640"" cellpadding=""0"" cellspacing=""0"" class=""container"" style=""background-color: {0};"" bgcolor=""{0}"">
//                                            <tr>
//                                                <td align=""left"" valign=""top"">
//                                                    <table border=""0"" width=""100%"" cellpadding=""0"" cellspacing=""0"">
//                                                        <tr>
//                                                            <td align=""center"" valign=""top"">
//                                                                <img class=""resizeImg"" style=""display:block;"" src=""{1}"" alt="""" border=""0"">
//                                                            </td>
//                                                        </tr>
//                                                    </table>
//                                                </td>
//                                            </tr>
//                                        </table>
//                                    </td>
//                                </tr>
//								</table>
//                        </td>
//                    </tr>
//                    <!-- body part 1 closed -->
//                </table>
//
//            </td>
//        </tr>", img.bgColor, "images/" + img.imagePath.Substring(img.imagePath.LastIndexOf("\\")));
//                    list.Add(img);
//                    #endregion HTML


                    AdiImage img = (AdiImage)row.Cells["Object"].Value;
                    img.HTML = String.Format(@"      <tr>
            <td>
                <table cellpadding=""0"" cellspacing=""0"" border=""0"" width=""100%"">
                    <!-- body part 1 starts -->
                    <tr>
                        <td>
                            <table border=""0"" cellpadding=""0"" cellspacing=""0"" width=""100%"">
                                <tr>
                                    <td align=""center"" valign=""top"" style=""background-color:#{0};"">
                                        <table border=""0"" width=""640"" cellpadding=""0"" cellspacing=""0"" class=""container"" style=""background-color:#{0};"">
                                            <tr>
                                                <td align=""left"" valign=""top"" style=""{2}"" width=""{5}%"">
                                                    <table border=""0"" width=""100%"" cellpadding=""0"" cellspacing=""0"">
                                                        <tr>
                                                            <td {1} >
{6}
                                                                <img class=""resizeImg"" style=""display:block;"" src=""{3}"" alt=""{4}"" >
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
								</table>
                        </td>
                    </tr>
                    <!-- body part 1 closed -->
                </table>

            </td>
        </tr>", img.background_color,img.alignment,img.style, "images/" + img.imagePath.Substring(img.imagePath.LastIndexOf("\\")),img.alternateText,img.width,img.alink);
                   //concentrate
                    list.Add(img);
                }
                if (row.Cells["Type"].Value.ToString() == "Text")
                {
                    AdiText txt = (AdiText)row.Cells["Object"].Value;
                   // txt.bgColor = row.Cells["BgColor"].Value != null ? row.Cells["BgColor"].Value.ToString() : null;
                   // txt.text = row.Cells["text"].Value != null ? row.Cells["text"].Value.ToString() : null;
//                    txt.HTML = string.Format(@"<tr>
//                                    <td align=""center"" valign=""top"" class=""mobile-padding"" style=""padding-left:0px; padding-right:0px;background-color:{0};"" bgcolor=""{0}"">
//                                        <table border=""0"" cellpadding=""0"" cellspacing=""0"">
//                                            <tr>
//                                                <td align=""center"" valign=""middle"" style=""font-size: 18px; font-family: Arial;  color: #737373; "">
//                                                    <span>
//                                                       {1}
//													   </span>
//                                                </td>
//                                            </tr>
//                                        </table>
//                                    </td>
//                                </tr>", txt.bgColor, txt.text);

                    txt.HTML = string.Format(@"<tr>
                                    <td >
                                        <table border=""0"" cellpadding=""0"" width=""640"" align=""center"" class=""templateColumns100"" cellspacing=""0"">
                                            <tr>
                                                <td {0}  style=""{1}"">
                                                    <span>
                                                       {2}
													   </span>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>", txt.alignment, txt.style,txt.text);

                    list.Add(txt);
                }
//                if (row.Cells["Type"].Value.ToString() == "Spacer")
//                {
//                    AdiSpacer spc = new AdiSpacer();
//                    spc.bgColor = row.Cells["BgColor"].Value != null ? row.Cells["BgColor"].Value.ToString() : null;
//                    spc.height = row.Cells["spacerHeight"].Value != null ? row.Cells["spacerHeight"].Value.ToString() : null;
//                    spc.HTML = string.Format(@"<tr>
//                                    <td height=""{0}"" align=""center"" valign=""middle"" style=""font-size:0; mso-line-height-alt:0; mso-margin-top-alt:1px;background-color:{1};"">
//                                        <img height=""{0}"" src=""http://test.adidas-news.adidas.com/res/adidas-test/spacer.gif"" border=""0"" alt="""" style=""display:block;"">
//                                    </td>
//                                </tr>", spc.height, spc.bgColor);
//                    list.Add(spc);
//                }
                if (row.Cells["Type"].Value.ToString() == "Responsive 1X2")
                {
                    Responsive_1X2 spc = new Responsive_1X2();
                    spc.bgcolor = row.Cells["BgColor"].Value != null ? row.Cells["BgColor"].Value.ToString() : null;
                    spc.paths = row.Cells["ImagePath"].Value != null ? row.Cells["ImagePath"].Value.ToString() : null;
                    string[] pathArray = spc.paths.Split(',');

                    StringBuilder sb = new StringBuilder();

                    foreach (var item in pathArray)
                    {
                        string partialBlock = String.Format(@"<td align=""left"" valign=""top"" style=""padding-left:10px; padding-right:10px;"" class=""story-left"" width=""50%"">
          <table border=""0"" width=""100%"" cellpadding=""0"" cellspacing=""0"">
            <tr>
              <td align=""left"" valign=""top"">
                <a href=""http://t.adidas-news.adidas.com//r/?id=h9cc1fdc1,4a167a82,4a167b50&p1=284IM7GGQFEQ1JRG"" target=""_blank"" _label=""Originals""><img class=""resizeImg"" style=""display:block;"" border=""0"" src=""{0}"" alt=""Originals"" />
                </a>
              </td>
            </tr>
			</table>
			</td>", "images/" + item.Substring(item.LastIndexOf("\\")));
                        sb.Append(partialBlock);
                    }

                    spc.HTML = string.Format(@"<tr>
  <td align=""center"" valign=""top"" style=""background-color: #f9f9f9;"" bgcolor=""#f9f9f9"">
    <table border=""0"" width=""640"" cellpadding=""0"" cellspacing=""0"" class=""container"" style=""background-color: #f9f9f9;"" bgcolor=""#f9f9f9"">
      <tr>
{0}
</tr>
			</table>
			</td>
			</tr>
			", sb.ToString());
                    list.Add(spc);
                }

                if(row.Cells["Type"].Value.ToString() == "Responsive 1Xi Text")
                {
//                    Adi_Responsive_Text_1Xi add = (Adi_Responsive_Text_1Xi)row.Cells["ImagePath"].Value;
//                    StringBuilder spc = new StringBuilder();
//                    foreach (var item in add.controls)
//                    {
//                        spc.Append(string.Format(@"<td align=""left"" valign=""top"" style=""padding:0px; margin:0px;"" class=""templateColumnContainer"" width=""{1}"">
//                                            <table width=""100%"" bgcolor=""#fff"" style=""background:#fff; mso-table-lspace:0pt; mso-table-rspace:0pt;"" align=""left"" border=""0"" cellpadding=""0"" cellspacing=""0"" class=""templateColumns100"">
//                                                <tbody><tr>
//                                                    <td class=""padd-h40_3_2d border-zero_3_2d font24-l34_3_2d xspace-summary_3_2d-divT"" style=""padding-bottom:15px;padding-top:32px; font-family:Arial; font-size:14px; font-weight:bold; color:#333333; border-bottom:1px solid #ebebeb; "">{0}</td>
//                                                </tr>
//                                                <tr>
//                                                    
//                                                </tr>
//                                                </tbody></table>
//                                         </td>", item.GetTextBoxValue(),640/add.elements));
//                    }
//                    add.HTML = string.Format(@"<tr>
//    <td align=""center"" valign=""top"">
//        <!-- Purchase Summary part starts -->        
//        <table cellspacing=""0"" cellpadding=""0"" width=""100%"" align=""center"" border=""0"">
//            <tr>
//                 <td align=""center"" valign=""top"">        
//                    <table border=""0"" width=""640"" cellpadding=""0"" cellspacing=""0"" class=""container""><tr>
//                            <td align=""left"" valign=""top"">
//                                <table class=""templateColumns100"" cellpadding=""0"" cellspacing=""0"" border=""0"">
//                                    <tbody><tr>{0}  </tr>
//                                </tbody></table>
//                            </td>
//                        </tr> </table>        
//                </td>
//            </tr>
//        </table>
//        <!-- Purchase Summary part closed -->        
//    </td>
//</tr> ", spc.ToString());

                    AdiText_1xi add = (AdiText_1xi)row.Cells["ImagePath"].Value;
                    StringBuilder spc = new StringBuilder();
                    foreach (var item in add.controls)
                    {
                        spc.Append(string.Format(@"<td  {0} style=""padding:0px; margin:0px;"" class=""templateColumnContainer"" width=""{1}"">
                                                                <table width=""100%""  style=""mso-table-lspace:0pt; mso-table-rspace:0pt;"" align=""left"" border=""0"" cellpadding=""0"" cellspacing=""0"" class=""templateColumns100"">
                                                                    <tbody><tr>
                                                                        <td {0} style=""{2}"" >{3}</td>
                                                                    </tr>
                                                                    <tr>
                                                                        
                                                                    </tr>
                                                                    </tbody></table>
                                                             </td>", item.GetAlignmentValues(), 640 / add.elements,item.GetValueOfStyle(),item.GetText()));
                    }
                    add.HTML = string.Format(@"<tr>
                        <td align=""center"" valign=""top"">
                            <!-- Purchase Summary part starts -->        
                            <table cellspacing=""0"" cellpadding=""0"" width=""100%"" align=""center"" border=""0"">
                                <tr>
                                     <td align=""center"" valign=""top"">        
                                        <table border=""0"" width=""640"" cellpadding=""0"" cellspacing=""0"" class=""container""><tr>
                                                <td align=""left"" valign=""top"">
                                                    <table class=""templateColumns100"" cellpadding=""0"" cellspacing=""0"" border=""0"">
                                                        <tbody><tr>{0}  </tr>
                                                    </tbody></table>
                                                </td>
                                            </tr> </table>        
                                    </td>
                                </tr>
                            </table>
                            <!-- Purchase Summary part closed -->        
                        </td>
                    </tr> ", spc.ToString());

                    list.Add(add);
                }
                
            }
            WriteContents(list);
        }

        private void cmbType_SelectedIndexChanged(object sender, EventArgs e)
        {
            DecideVisibility();
        }

        private void DecideVisibility()
        {
            if (cmbType.SelectedItem.ToString() == "Image")
            {
                btnOpenFile.Visible = true;
                txtgeneric.Visible = false;
                generic.Visible = false;
            }
            if (cmbType.SelectedItem.ToString() == "Text")
            {
                generic.Text = "Enter Text";
                txtgeneric.Visible = true;
                btnOpenFile.Visible = false;
            }
            if (cmbType.SelectedItem.ToString() == "Spacer")
            {
                generic.Text = "Height of Spacer";
                txtgeneric.Visible = true;
                btnOpenFile.Visible = false;
            }
            if (cmbType.SelectedItem.ToString() == "Responsive 1X2")
            {
                openFileDialog1.Multiselect = true;
            }
        }

        private void btnOpenFile_Click(object sender, EventArgs e)
        {

            openFileDialog1.ShowDialog();
            openFileDialog1.Filter = "*.png|*.jpg";
            //textBox1.Text = op1.FileName;

            //foreach (string s in op1.FileNames)
            //{
            //    FName = s.Split('\\');
            //    File.Copy(s, "C:\\file\\" + FName[FName.Length - 1]);
            //    count++;
            //}
            if (!string.IsNullOrEmpty(openFileDialog1.FileName) && openFileDialog1.FileName != "openFileDialog1")
                MessageBox.Show("File Uploaded Successfully");
            else
                MessageBox.Show("No File Uploaded");
        }

        private void txtBgColor_Click(object sender, EventArgs e)
        {

        }

        public void WriteContents(List<object> list)
        {

            FileStream file = null;
            StreamWriter writerObj = null;

            #region body

            string data = @"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html lang=""en"">
<head>
    <title>adidas</title>

    <meta name=""viewport"" content=""initial-scale=1.0"">    <!-- So that mobile webkit will display zoomed in -->
    <meta name=""format-detection"" content=""telephone=no""> <!-- disable auto telephone linking in iOS -->
    <style>
        .ReadMsgBody {
            width: 100%;
            background-color: #fff;
        }

        .ExternalClass {
            width: 100%;
            background-color: #fff;
        }

            .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {
                line-height: 100%;
            }

        body {
            -webkit-text-size-adjust: none;
            -ms-text-size-adjust: none;
        }

        table {
            border-spacing: 0;
            border-collapse: collapse;
            mso-table-lspace: 0;
            mso-table-rspace: 0;
        }

            table td {
                border-collapse: collapse;
                mso-table-lspace: 0;
                mso-table-rspace: 0;
            }

        .yshortcuts a {
            border-bottom: none !important;
        }

        .appleLinks {
            font-family: Arial;
            color: #666666 !important;
            text-decoration: none;
        }

        .appleLinks-grey a {
            color: #828280 !important;
            text-decoration: none;
        }

        .appleLinks-white a {
            color: #fff !important;
            text-decoration: none;
        }

        #appleLinks-newgrey a {
            color: #5d5d5d !important;
            text-decoration: none;
        }

        p {
            margin: 0;
            padding: 0;
            margin-bottom: 0;
        }

        body {
            -webkit-text-size-adjust: none;
            -ms-text-size-adjust: none;
        }

        body {
            margin: 0;
            padding: 0;
        }

        img {
            border: 0;
        }

        table {
            border-spacing: 0;
            border-collapse: collapse;
            mso-table-lspace: 0;
            mso-table-rspace: 0;
        }

            table td {
                border-collapse: collapse;
                mso-table-lspace: 0;
                mso-table-rspace: 0;
            }

        appleLinks-white a {
            color: #fff !important;
            text-decoration: none;
        }

        /************WNDMAN CSS******************/
        /*DO NOT EDIT*/
        @media screen and (max-width: 639px) {
            table[class=""container""] {
                width: 100% !important;
            }

            tr[class=""hideMobile""] {
                display: none;
            }

            td[class=""hideMobile""] {
                display: none !important;
            }

            td[id=""hideMobile""] {
                display: none !important;
            }

            td[class=""leftQuot""] {
                padding-left: 0 !important;
                padding-right: 8px !important;
            }

            td[class=""rightQuot""] {
                padding-right: 0 !important;
                padding-left: 8px !important;
            }

            td[class=""speech""] {
                padding-left: 0 !important;
                padding-right: 0 !important;
                text-align: left;
            }

            img[class=""hideMobile""] {
                display: none !important;
            }

            img[class=""resizeImg""] {
                width: 100% !important;
            }

            img[class=""resizeImg80""] {
                width: 80% !important;
            }

            div[class=""hideDesktop""] {
                display: block !important;
                margin: 0;
                padding: 0;
                overflow: visible !important;
                width: auto !important;
                height: auto !important;
                max-height: inherit !important;
            }

            img[class=""hideDesktop""] {
                display: block !important;
                margin: 0;
                padding: 0;
                overflow: visible !important;
                width: 100% !important;
                height: auto !important;
                max-height: inherit !important;
            }

            tr[class=""show-mobile""] {
                display: block !important;
            }

            td[class=""show-mobile""] {
                display: block !important;
                width: auto !important;
                max-height: inherit !important;
                overflow: visible !important;
                float: none !important;
            }

            td[class=""mobile-padding""] {
                padding-left: 15px !important;
                padding-right: 15px !important;
            }

            td[class=""mobile-padding-left""] {
                padding-left: 15px !important;
                padding-right: 0 !important;
            }

            td[class=""force-col""] {
                display: block;
                padding-right: 0 !important;
                width: 100%;
                border: 0 !important;
            }

            table[class=""col""] {
                float: none !important;
                width: 100% !important;
            }

            table[class=""col-3""] {
                float: none !important;
                width: 100% !important;
            }

            td[class=""centerText""] {
                text-align: center;
            }

            td[class=""linkFarmText""] {
                padding-left: 10px !important;
                font-size: 16px !important;
            }

            td[id=""resetPadding""] {
                padding: 0 !important;
            }

            td[class=""resetPadding""] {
                padding: 0 !important;
            }

            td[class=""resetBorderRightBottom""] {
                border-right: 0 !important;
                border-bottom: 0 !important;
            }

            td[class=""resetBorderRight""] {
                border-right: 1px solid #ffffff !important;
            }

            td[id=""addBorderBottom""] {
                border-bottom: 1px dashed #ebebeb !important;
            }

            td[class=""height30""] {
                height: 30px !important;
            }

            td[class=""buttonPadding""] {
                padding-left: 15px !important;
            }

            td[class=""centerImage""] {
                margin-left: auto !important;
                margin-right: auto !important;
            }

            td[class=""noBorder""] {
                border: none !important;
            }

            table[class=""width70""] {
                width: 70% !important;
            }

            table[class=""width80""] {
                width: 80% !important;
            }

            table[class=""width90""] {
                width: 90% !important;
            }

            table[class=""width95""] {
                width: 95% !important;
            }

            table[class=""width100""] {
                width: 100% !important;
            }

            table[class=""resetBorders""] {
                border: 0 !important;
            }

            table[id=""resetBorders""] {
                border: 0 !important;
            }

            td[class=""header-logo""] {
                padding-bottom: 20px !important;
                border-bottom: 1px solid #444444;
            }

            td[class=""header-menu""] {
                padding-top: 10px !important;
            }

            td[class=""height10""] {
                height: 10px !important;
            }

            img[class=""height10""] {
                height: 10px !important;
            }

            td[class=""mobile-menu-padding""] {
                width: auto !important;
                padding-left: 10px !important;
            }

            table[id=""footer-border-bottom""] {
                border-bottom: 1px solid #ebebeb !important;
            }

            td[class=""reset-height""] {
                height: auto !important;
            }

            table[class=""add-top-bot-margin""] {
                margin-top: 30px !important;
                margin-bottom: 30px !important;
            }

            table[id=""footer-menu""] td {
                display: inline-block;
            }

            table[id=""footer-menu""] {
                text-align: center;
                line-height: 20px;
            }

            td[class=""mobile-font-16""] {
                font-size: 16px !important;
            }

            td[class=""mobile-font-14""] {
                font-size: 14px !important;
            }

            td[class=""mobile-font-12""] {
                font-size: 12px !important;
            }

            table[id=""padding-20""] {
                margin-left: 20px;
            }

            table tr td img[id=""action""] {
                margin-left: 5px;
            }

            table[id=""action2""] {
                margin-top: 15px;
            }

            td[class=""height20""] {
                height: 20px !important;
            }

            table[id=""marg-bot-20""] {
                margin-bottom: 20px !important;
            }

            td[class=""mobile-font-25""] {
                font-size: 25px !important;
            }

            td[class=""story-left""] {
                padding-left: 15px !important;
                padding-right: 7px !important;
            }

            td[class=""story-right""] {
                padding-left: 7px !important;
                padding-right: 15px !important;
            }

            td[class=""voucher-btn""] a {
                font-weight: normal !important;
                font-size: 18px !important;
            }

            table[id=""add-bot-margin-10""] {
                margin-bottom: 10px !important;
            }

            table[id=""add-bot-margin-30""] {
                margin-bottom: 30px !important;
            }

            table[class=""dialog-btn""] {
                width: 200px !important;
                margin-top: 20px !important;
            }

            span[class=""dialog-font""] {
                display: block !important;
                font-size: 16px !important;
            }

            td[class=""font14-reset-lineheight""] {
                font-size: 14px !important;
                line-height: 18px !important;
            }

            td[id=""width50""] {
                width: 50% !important;
            }

            td[class=""mobile-font-17""] {
                font-size: 16px !important;
            }

            td[class=""resetheight""] {
                height: auto;
            }
        }
        /*DO NOT EDIT*/
        /************WNDMAN CSS******************/
        @media screen and (max-width: 639px) {
            .autoheight {
                height: auto !important;
            }

            .responsive-banner-image {
                width: 100% !important;
            }

            .changeBorder2 {
                border-right: 0 !important;
                border-bottom: 10px solid #EAEAEA;
            }

            .alignMobile {
                display: block !important;
                width: 100% !important;
                align: center !important;
                padding-left: 55px !important;
            }

            .alignMobile1 {
                display: block !important;
                align: center !important;
                padding-left: 55px !important;
            }

            .paddingTopMobile {
                padding-top: 10px !important;
            }

            .paddingMobile {
                padding-top: 10px !important;
                padding-bottom: 10px !important;
                align: center !important;
                text-align: center !important;
            }

            .hideMobile {
                display: none;
            }

            .fasteasyCheckout_padding {
                border-right: 0 none !important;
                padding-top: 40px !important;
                width: 100% !important;
            }

            .productContainer_image {
                width: 200px !important;
                float: left !important;
            }

            .productImage_abandonbrowse {
                width: 200px !important;
            }

            .newHeight2 {
                height: 0 !important;
                font-size: 0 !important;
            }

            .leftMargin {
                padding-left: 27px !important;
                text-align: left !important;
            }

            .leftMarginShopnow {
                padding-left: 18px !important;
            }

            .acCodetxtwidth {
                width: 94% !important;
            }

            .width100 {
                width: 100% !important;
            }

            .fasteasyCheckout_paddingTabletoppadding {
                padding-top: 40px !important;
            }

            .templateColumns {
                width: 320px !important;
            }

            .templateColumns100 {
                width: 100% !important;
            }

            .templateColumnContainer {
                display: block !important;
                width: 100% !important;
            }

            .deliveryBlockContainer {
                border-bottom: 1px solid #ebebeb;
                border-right: 0 none !important;
                padding-bottom: 40px !important;
                width: 100% !important;
            }



            .buttonpaddingBottom {
                padding-bottom: 10px !important;
            }

            .leftMargin2 {
                border: 0 !important;
                padding-left: 27px !important;
            }

            table[class=""aem-main-wrapper""] {
                width: 100% !important;
            }

            td[class=""aem-hide-mobile""] {
                display: none !important;
            }

            td[class=""aem-main-wrapper""] {
                width: 100% !important;
                display: block !important;
            }

            table[class=""aem-width100""] {
                width: 100% !important;
            }

            td[class=""aem-align-centertxt""] {
                text-align: center;
            }

            img[class=""aem-img-resize""] {
                width: 100% !important;
            }

            img[class=""aem-prd-img""] {
                width: 93% !important;
            }

            a[class=""aem-free-delivery""] {
                font-size: 11px !important;
                font-weight: 400 !important;
            }

            td[class=""aem-shrink-txt""] {
                font-size: 14px !important;
            }

            table[class=""aem-message-wrapper""] {
                width: 99.8% !important;
            }

            td[class=""aem-main-left-wrapper""], td[class=""aem-main-right-wrapper""] {
                width: 97.5% !important;
                display: block !important;
            }

            table[class=""aem-side-bar-exp-left""], table[class=""aem-order-details""] {
                width: 100% !important;
            }

            table[class=""aem-side-bar-right""] {
                border-top: 5px solid #EAEAEA !important;
            }

            table[class=""aem-order-details""] {
                border-top: 5px solid #EAEAEA !important;
            }

            table[class=""aem-you-like""] {
                width: 100% !important;
            }

            td[class=""aem-ord-detl-heading""] {
                padding-left: 10px !important;
            }

            td[class=""aem-order-wrapper""] {
                width: 97% !important;
                display: block !important;
            }

            td[class=""aem-prd-desc aem-desc1""], td[class=""aem-col-heading""], td[class=""aem-col-row""] {
                font-size: 11px !important;
                word-wrap: break-word;
            }

            table[class=""aem-prd-table""] {
                width: 100% !important;
            }

            td[class=""aem-dynamic-txt""] {
                font-size: 30px !important;
            }

            td[class=""aem-footer-links-last""], td[class=""aem-footer-links""] {
                padding: 10px 0 !important;
            }

            td[class=""aem-footer-links-last""] {
                border-bottom: 0 !important;
            }

            td[class=""aem-order-container""] {
                width: 100% !important;
                display: block !important;
            }

            td[class=""aem-order-mid-container""] {
                width: 96% !important;
                display: block !important;
                padding: 0 !important;
                padding-left: 8px !important;
            }

            table[class=""aem-order-mid-table""] {
                border-top: 1px solid #cacaca;
                padding-left: 10px !important;
            }

            table[class=""aem-order-mid-table-top""] {
                border-top: 0 solid #cacaca;
                padding-left: 10px !important;
            }

            td[class=""aem-bottom""] {
                padding-bottom: 10px !important;
            }

            td[class=""aem-top""] {
                padding-top: 10px !important;
            }

            td[class=""aem-step-order""] {
                width: 225px !important;
            }
        }

        @media screen and (max-width: 480px) {
            .ordersummrypadding10 {
                padding-left: 10px !important;
            }

            .changeBorder2 {
                border-right: 0 !important;
                border-bottom: 10px solid #EAEAEA;
            }

            .autoheight {
                height: auto !important;
            }

            .alignMobile {
                display: block !important;
                width: 100% !important;
                align: center !important;
                padding-left: 55px !important;
            }

            .alignMobile1 {
                display: block !important;
                align: center !important;
                padding-left: 55px !important;
            }

            td[class=""aem-shrink-txt""] {
                font-size: 11px !important;
            }

            table[class=""aem-message-wrapper""] {
                width: 99% !important;
            }

            td[class=""aem-main-wrapper""] {
                width: 96% !important;
                display: block !important;
            }

            td[class=""aem-main-left-wrapper""], td[class=""aem-main-right-wrapper""] {
                width: 96% !important;
                display: block !important;
            }

            img[class=""aem-prd-img""] {
                width: 120% !important;
            }

            td[class=""aem-order-wrapper""] {
                width: 95% !important;
                display: block !important;
            }

            table[class=""aem-prd-table""] {
                width: 102% !important;
            }

            td[class=""aem-dynamic-txt""] {
                font-size: 25px !important;
            }

            td[class=""aem-question-one""] {
                width: 100% !important;
                display: block !important;
                padding-bottom: 10px !important;
            }

            td[class=""aem-questions-two""] {
                padding: 0 !important;
            }

            td[class=""aem-second-row""] {
                width: 85% !important;
                display: block !important;
                padding-bottom: 10px !important;
                padding-left: 10px !important;
            }

            td[class=""aem-second-col""] {
                width: 85% !important;
                display: block !important;
                padding-bottom: 10px !important;
                padding-left: 20px !important;
            }

            td[class=""aem-youmay-like""] {
                font-size: 24px !important;
            }

            .hideMobile {
                display: none !important;
            }

            .width100 {
                width: 100% !important;
            }

            .leftMargin {
                padding-left: 27px !important;
                text-align: left !important;
            }

            .lessleftMargin {
                padding-left: 16px !important;
            }

            .responsive-banner-image {
                width: 100% !important;
            }

            .width290 {
                width: 290px !important;
            }

            .hideDesktop {
                display: block !important;
            }

            .productImage {
                width: 60% !important;
            }

            .lessleftMargin45 {
                padding-left: 60px !important;
                text-align: left !important;
            }

            .lessleftMargin80 {
                padding-left: 45px !important;
                text-align: left !important;
                width: 100% !important;
            }

            .arrow-white1 {
                padding-left: 65px !important;
            }

            .arrow-white2 {
                padding-left: 38px !important;
            }

            .arrow-white3 {
                padding-left: 60px !important;
            }

            .width40 {
                width: 50% !important;
            }

            .midbutton {
                width: 80% !important;
            }

            .productContainer_image {
                width: 130px !important;
                float: left !important;
                padding: 8px 10px;
            }

            .productImage_abandonbrowse {
                width: 140px !important;
            }

            .paddingProductcontainer {
                padding: 0 10px !important;
            }

            .newHeight {
                height: 0 !important;
            }


            .width320 {
                width: 320px !important;
            }

            .productsContainerE1 {
                padding: 0 !important;
            }

            .productCol {
                width: 310px !important;
            }
        }

        @media only screen and (max-width: 639px) {
            .leftMargin3 {
                border: 0 !important;
                padding-left: 60px !important;
            }
        }

        @media screen and (max-width: 320px) {
            table[class=""aem-main-wrapper""] {
                width: 320px !important;
            }

            table[class=""aem-message-wrapper""] {
                width: 99% !important;
            }

            td[class=""aem-main-wrapper""] {
                width: 95% !important;
                display: block !important;
            }

            td[class=""aem-main-left-wrapper""], td[class=""aem-main-right-wrapper""] {
                width: 96% !important;
                display: block !important;
            }

            img[class=""aem-prd-img""] {
                width: 120% !important;
            }

            table[class=""aem-prd-table""] {
                width: 101% !important;
            }
        }
        /*******************font-Size-definition Mobile***********************************/
        @media screen and (max-width: 639px) {
            .fontSize72 {
                font-size: 36px !important;
                font-weight: 700 !important;
            }

            .fontSize48 {
                font-size: 24px !important;
                font-weight: 700 !important;
            }

            .fontSize32 {
                font-size: 16px !important;
                font-weight: 700 !important;
            }

            .fontSize70 {
                font-size: 45px !important;
                font-weight: 700 !important;
            }

            .fontSize46 {
                font-size: 30px !important;
                font-weight: 700 !important;
            }

            .fontSize28 {
                font-size: 19px !important;
                font-weight: 700 !important;
            }

            .fontSize24 {
                font-size: 16px !important;
                font-weight: 700 !important;
            }

            .fontSize18 {
                font-size: 14px !important;
                font-weight: 700 !important;
            }

            .fontSize17 {
                font-size: 14px !important;
                font-weight: 700 !important;
            }

            .fontSize14 {
                font-size: 13px !important;
                font-weight: 400 !important;
            }

            .fontSize13 {
                font-size: 12px !important;
                font-weight: 400 !important;
            }

            .fontSize18n {
                font-size: 14px !important;
                font-weight: 400 !important;
            }

            .buttonAjustHeight {
                height: 33px !important;
            }

            .fontadjust12 {
                font-size: 12px !important;
            }

            .paddingTop48 {
                padding-top: 48px !important;
            }

            .paddingTop32 {
                padding-top: 32px !important;
            }
        }


        .headcolor {
            color: #999999 !important;
        }

        @media screen and (max-width: 639px) {
            .paddingMobileZero {
                display: block !important;
                width: 100% !important;
                padding-right: 0px !important;
            }
        }

        @media screen and (max-width: 639px) {


            .shoepadding {
                padding-left: 30px !important;
            }

            .mobilecenter {
                text-align: center !important;
            }

            .paddingzero {
                padding-right: 0px !important;
                padding-left: 0px !important;
            }

            .mobiletextpadding {
                padding-left: 10px;
                padding-right: 10px;
            }

            .leftpaddingmobile {
                padding-left: 10px;
            }

            .fontadjust10 {
                font-size: 14px !important;
                padding-top: 5px !important;
            }

            .tablecolorchange {
                display: block !important;
                width: 100% !important;
                background-color: #FFFFFF;
                padding-top: 5px !important;
                padding-bottom: 5px !important;
            }

            .textcolor {
                color: #000000 !important;
            }

            .paddingtop {
                padding-top: 0px !important;
            }

            .bordermobile {
                border-right: 0px !important;
            }

            .mobilebottomborder {
                display: block !important;
                width: 100% !important;
                border-bottom: 1px solid #f2f2f2;
            }

            .paddingzero480 {
                padding-left: 0px !important;
                padding-top: 10px !important;
            }

            .mobilepaddingheader {
                display: block !important;
                width: 100% !important;
                padding-top: 5px !important;
                padding-bottom: 5px !important;
            }

            .paddingobjectives {
                width: 100% !important;
                padding-left: 60px !important;
            }

            .paddinglogo {
                padding-left: 150px !important;
            }
        }



        @media screen and (max-width: 480px) {


            .paddingzero480 {
                padding-left: 0px !important;
            }

            .fontadjust10 {
                font-size: 8px !important;
            }

            .paddingtop {
                padding-bottom: 0px !important;
            }
        }


        @font-face {
            font-family: 'AdiHausPS_BD';
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/AdihausDIN-Bold.eot'); /* IE9 Compat Modes */
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/AdihausDIN-Bold.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */
            url('http://test.adidas-news.adidas.com/res/adidas-test/AdihausDIN-Bold.woff') format('woff'), /* Modern Browsers */
            url('http://test.adidas-news.adidas.com/res/adidas-test/AdihausDIN-Bold.ttf') format('truetype'); /* Safari, Android, iOS */
        }



        @font-face {
            font-family: 'ColfaxWebBlack';
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/ColfaxWebBlack.eot'); /* IE9 Compat Modes */
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/ColfaxWebBlack.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */
            url('http://test.adidas-news.adidas.com/res/adidas-test/ColfaxWebBlack.woff') format('woff'), /* Modern Browsers */
            url('http://test.adidas-news.adidas.com/res/adidas-test/ColfaxWebBlack.ttf') format('truetype'); /* Safari, Android, iOS */
        }

        @font-face {
            font-family: 'ReefontRegular';
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/Reefont-Regular.eot'); /* IE9 Compat Modes */
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/Reefont-Regular.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */
            url('http://test.adidas-news.adidas.com/res/adidas-test/Reefont-Regular.woff') format('woff'), /* Modern Browsers */
            url('http://test.adidas-news.adidas.com/res/adidas-test/Reefont-Regular.ttf') format('truetype'); /* Safari, Android, iOS */
        }

        @font-face {
            font-family: 'ReefontBold';
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/Reefont-Bold.eot'); /* IE9 Compat Modes */
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/Reefont-Bold.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */
            url('http://test.adidas-news.adidas.com/res/adidas-test/Reefont-Bold.woff') format('woff'), /* Modern Browsers */
            url('http://test.adidas-news.adidas.com/res/adidas-test/Reefont-Bold.ttf') format('truetype'); /* Safari, Android, iOS */
        }

        @font-face {
            font-family: 'ArialBlack';
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/arial_black.eot'); /* IE9 Compat Modes */
            src: url('http://test.adidas-news.adidas.com/res/adidas-test/arial_black.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */
            url('http://test.adidas-news.adidas.com/res/adidas-test/arial_black.woff') format('woff'), /* Modern Browsers */
            url('http://test.adidas-news.adidas.com/res/adidas-test/arial_black.ttf') format('truetype'); /* Safari, Android, iOS */
        }




        /*******************font-Size-definition Desktop***********************************/
        .fontSize72 {
            font-size: 72px !important;
            font-weight: 700 !important;
        }

        .fontSize48 {
            font-size: 48px !important;
            font-weight: 700 !important;
        }

        .fontSize32 {
            font-size: 32px !important;
            font-weight: 700 !important;
        }

        .fontSize70 {
            font-size: 70px !important;
            font-weight: 700 !important;
        }

        .fontSize46 {
            font-size: 46px !important;
            font-weight: 700 !important;
        }

        .fontSize28 {
            font-size: 28px !important;
            font-weight: 700 !important;
        }

        .fontSize24 {
            font-size: 24px !important;
            font-weight: 700 !important;
        }

        .fontSize18 {
            font-size: 18px !important;
            font-weight: 700 !important;
        }

        .fontSize17 {
            font-size: 17px !important;
            font-weight: 700 !important;
        }

        .fontSize14 {
            font-size: 14px !important;
            font-weight: 400 !important;
        }

        .fontSize13 {
            font-size: 13px !important;
            font-weight: 400 !important;
        }

        .fontSize18n {
            font-size: 18px !important;
            font-weight: 400 !important;
        }

        /*******************font-Size-definition Mobile***********************************/
        @media screen and (max-width: 639px) {
            .fontSize72 {
                font-size: 36px !important;
                font-weight: 700 !important;
            }

            .fontSize48 {
                font-size: 24px !important;
                font-weight: 700 !important;
            }

            .fontSize32 {
                font-size: 16px !important;
                font-weight: 700 !important;
            }

            .fontSize70 {
                font-size: 45px !important;
                font-weight: 700 !important;
            }

            .fontSize46 {
                font-size: 30px !important;
                font-weight: 700 !important;
            }

            .fontSize28 {
                font-size: 19px !important;
                font-weight: 700 !important;
            }

            .fontSize24 {
                font-size: 16px !important;
                font-weight: 700 !important;
            }

            .fontSize18 {
                font-size: 14px !important;
                font-weight: 700 !important;
            }

            .fontSize17 {
                font-size: 14px !important;
                font-weight: 700 !important;
            }

            .fontSize14 {
                font-size: 13px !important;
                font-weight: 400 !important;
            }

            .fontSize13 {
                font-size: 12px !important;
                font-weight: 400 !important;
            }

            .fontSize18n {
                font-size: 14px !important;
                font-weight: 400 !important;
            }

            .buttonAjustHeight {
                height: 33px !important;
            }

            .fontadjust12 {
                font-size: 12px !important;
            }

            .paddingTop48 {
                padding-top: 48px !important;
            }

            .paddingTop32 {
                padding-top: 32px !important;
            }

            .paddingfooter {
                padding-left: 10px;
            }
        }
    </style>
</head>

<body style=""margin:0; padding: 0;"" bgcolor=""#ffffff"" leftmargin=""0"" topmargin=""0"" marginwidth=""0"" marginheight=""0"">

    <span style=""display:none !important; mso-hide:all;"">Ton accès privilègiè</span>

    <table border=""0"" width=""100%"" height=""100%"" cellpadding=""0"" cellspacing=""0"">

        <!-- Collect information about promo_codes -->
        <!-- ************************ BEGIN RENDER HEADER ************************ -->
        <tr><td align=""center"" valign=""top"">
        <tr>
            <td align=""center"" valign=""top"" style=""background-color:#ffffff;"" bgcolor=""#ffffff"">
                <table border=""0"" width=""640"" cellpadding=""0"" cellspacing=""0"" class=""container"" style=""background-color:#ffffff;"" bgcolor=""#ffffff"">
                    <tr>
                        <td align=""left"" valign=""top"">
                            <table border=""0"" width=""100%"" cellpadding=""0"" cellspacing=""0"">
                                <tr>
                                    <td height=""15"" align=""left"" valign=""middle"" style=""font-size:0; mso-line-height-alt:0; mso-margin-top-alt:1px;"">
                                        <img height=""15"" src=""http://test.adidas-news.adidas.com/res/adidas-test/spacer.gif"" border=""0"" alt="""" style=""display:block;"">
                                    </td>
                                </tr>
                                <tr>
                                    <td align=""left"" valign=""top"" style=""font-family:Arial; font-size:12px; color:#0185cc;"" class=""hideMobile"">


                                        <a style=""color:#0185cc; text-decoration:none;"" href="" http://t.neocrm-stg.adidas.com//r/?id=h22174bed,15bc2dc8,15bc2dda"" _label=""Promo"" target=""_blank"">Utilise ta récompense</a>


                                    </td>
                                    <td align=""right"" valign=""top"" style=""font-family:Arial; font-size:12px; color:#0185cc;"" class=""centerText"">

                                        <a href="" http://t.neocrm-stg.adidas.com//r/?id=h22174bed,15bc2dc8,15bc2ddb&amp;p1=i6R1uhWroHu2hEcceaZADHZEHYCpBP3O&amp;p2=63035078"" _type=""mirrorPage"" _label=""Mirror Page"" target=""_blank"" style=""color:#0185cc; text-decoration:none;"">Voir cet e-mail en ligne</a>

                                    </td>
                                </tr>
                                <tr>
                                    <td height=""15"" align=""left"" valign=""middle"" style=""font-size:0; mso-line-height-alt:0; mso-margin-top-alt:1px;"">
                                        <img height=""15"" src=""http://test.adidas-news.adidas.com/res/adidas-test/spacer.gif"" border=""0"" alt="""" style=""display:block;"">
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr></td></tr>
        <tr><td align=""center"" valign=""top"">
        <tr>
            <td align=""center"" valign=""top"" style=""background-color:#000000;"" bgcolor=""#000000"">
                <table border=""0"" width=""640"" cellpadding=""0"" cellspacing=""0"" class=""container"" style=""background-color:#000000;"" bgcolor=""#000000"">
                    <tr>
                        <td align=""left"" valign=""top"">
                            <table border=""0"" cellpadding=""0"" cellspacing=""0"" width=""100%"">
                                <tr>
                                    <td height=""18"" align=""left"" valign=""middle"" style=""font-size:0; mso-line-height-alt:0; mso-margin-top-alt:1px;"">
                                        <img height=""18"" src=""http://test.adidas-news.adidas.com/res/adidas-test/spacer.gif"" border=""0"" alt="""" style=""display:block;"">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table border=""0"" cellspacing=""0"" cellpadding=""0"" width=""100%"" align=""left"" class=""col"">
                                            <tr>
                                                <td align=""left"" valign=""top"">

                                                    <table width=""160"" class=""container"" border=""0"" align=""left"" cellpadding=""0"" cellspacing=""0"">
                                                        <tr>
                                                            <td align=""center"" valign=""top"" class=""header-logo"">
                                                                <a href="" http://t.neocrm-stg.adidas.com//r/?id=h22174bed,15bc2dc8,15bc2ddc"" _label=""youradidas logo"" title=""youradidas logo"" target=""_blank"">
                                                                    <img width=""160"" alt=""youradidas logo"" src=""http://test.adidas-news.adidas.com/res/adidas-test/adi_Brd_Loyalty_Logo_v2.jpg"" border=""0"" alt=""0"" style=""display:block;"">
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <!--[if mso]></td><td align=""left"" valign=""top""><![endif]-->
                                                    <table width=""480"" class=""container"" border=""0"" align=""right"" cellpadding=""0"" cellspacing=""0"">
                                                        <tr>
                                                            <td height=""3"" align=""left"" valign=""middle"" style=""font-size:0; mso-line-height-alt:0; mso-margin-top-alt:1px;"" class=""hideMobile"">
                                                                <img height=""3"" src=""http://test.adidas-news.adidas.com/res/adidas-test/spacer.gif"" border=""0"" alt="""" style=""display:block;"">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align=""left"" valign=""middle"" height=""19"" class=""header-menu"" style=""padding-left:10px;"" id=""resetPadding"">
                                                                <table border=""0"" cellpadding=""0"" cellspacing=""0"">
                                                                    <tr>
                                                                        <td align=""left"" valign=""middle"" style=""font-family:Arial; font-size:13px; color:#ffffff; padding-left:20px;"" class=""mobile-menu-padding"">
                                                                            <a href="""" _label="""" target=""_blank"" style=""color:#ffffff; text-decoration:none;""><strong></strong></a>
                                                                        </td>
                                                                        <td align=""left"" valign=""top"" style=""font-family:Arial; font-size:13px; color:#ffffff; padding-left:20px;"" class=""mobile-menu-padding"">
                                                                            <a href="""" _label="""" target=""_blank"" style=""color:#ffffff; text-decoration:none;""><strong></strong></a>
                                                                        </td>
                                                                        <td align=""left"" valign=""top"" style=""font-family:Arial; font-size:13px; color:#ffffff; padding-left:20px;"" class=""mobile-menu-padding"">
                                                                            <a href="""" _label="""" target=""_blank"" style=""color:#ffffff; text-decoration:none;""><strong></strong></a>
                                                                        </td>
                                                                        <td align=""left"" valign=""top"" style=""font-family:Arial; font-size:13px; color:#ffffff; padding-left:20px;"" class=""hideMobile"">
                                                                            <a href="""" _label="""" target=""_blank"" style=""color:#ffffff; text-decoration:none;""><strong></strong></a>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </td>
                                                            <td align=""right"" valign=""middle"" class=""header-menu"">
                                                                <table border=""0"" cellpadding=""0"" cellspacing=""0"">
                                                                    <tr>
                                                                        <td align=""right"" valign=""middle"" style=""font-family:Arial; font-size:13px; color:#ffffff; padding-right:8px;"" class=""mobile-menu-padding"">
                                                                            <a href="""" _label="""" target=""_blank"" style=""color:#ffffff; text-decoration:none;""><strong>Trouver un magasin</strong></a>
                                                                        </td>
                                                                        <td align=""right"" valign=""middle"" class=""hideMobile"">
                                                                            <img src=""http://test.adidas-news.adidas.com/res/adidas-test/adi_omni_channel_newsletter_footer_icon_storefinder.jpg"" border=""0"" alt=""0"" style=""display:block"">
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </table>

                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td height=""20"" align=""left"" valign=""middle"" style=""font-size:0; mso-line-height-alt:0; mso-margin-top-alt:1px;"" class=""height10"">
                                        <img height=""20"" src=""http://test.adidas-news.adidas.com/res/adidas-test/spacer.gif"" border=""0"" alt="""" style=""display:block;"" class=""height10"">
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr></td></tr>
        <tr><td align=""center"" valign=""top""></td></tr>
        <tr><td align=""center"" valign=""top""></td></tr>

        <!-- ************************ END RENDER HEADER ************************ -->
        <!-- ************************ BEGIN BODY CONTENT ************************ -->
";

            #endregion body

            try
            {
                var systemPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                var complete = Path.Combine(systemPath, "Automated HTML"); // For creating a Folder In My Documents
                string fullpath = GetUniqueTempPath(complete);
                string imagepath = Path.Combine(fullpath, "images");
                if (!Directory.Exists(fullpath))
                {
                    Directory.CreateDirectory(fullpath);
                    Directory.CreateDirectory(imagepath);
                }
                file = new FileStream(Path.Combine(fullpath, "generatedHtml.txt"), FileMode.Create);
                writerObj = new StreamWriter(file);
                writerObj.Write(QuoteSQLString(data));
                foreach (object item in list)
                {
                    if (item.GetType() == typeof(AdiImage))
                    {
                        AdiImage img = (AdiImage)item;
                        File.Copy(img.imagePath, imagepath + img.imagePath.Substring(img.imagePath.LastIndexOf("\\")), true);
                        writerObj.Write(QuoteSQLString(img.HTML));
                    }
                    if (item.GetType() == typeof(AdiText))
                    {
                        AdiText txt = (AdiText)item;
                        writerObj.Write(QuoteSQLString(txt.HTML));
                    }
                    if (item.GetType() == typeof(AdiSpacer))
                    {
                        AdiSpacer spc = (AdiSpacer)item;
                        writerObj.Write(QuoteSQLString(spc.HTML));
                    }
                    if (item.GetType() == typeof(Responsive_1X2))
                    {
                        Responsive_1X2 spc = (Responsive_1X2)item;
                        string[] pathArray = spc.paths.Split(',');

                        StringBuilder sb = new StringBuilder();

                        foreach (var itemImg in pathArray)
                        {
                            File.Copy(itemImg, imagepath + itemImg.Substring(itemImg.LastIndexOf("\\")), true);


                        }
                        writerObj.Write(QuoteSQLString(spc.HTML));
                    }
                    if (item.GetType() == typeof(AdiText_1xi))
                    {
                        AdiText_1xi spc = (AdiText_1xi)item;
                        writerObj.Write(QuoteSQLString(spc.HTML));
                    }
                }
                writerObj.Write("</td></tr></table></body></html>");
            }
            catch (Exception ex)
            {
                //FileException.Add("" + ex.Message);
            }
            finally
            {
                if (writerObj != null)
                    writerObj.Close();
                if (file != null)
                    file.Close();
            }
        }

        public void WriteContentsAfterBody(List<object> list)
        {
            foreach (var item in list)
            {

            }
        }

        public static string GetUniqueTempPath(string sPath)
        {
            string sUniqueName = Guid.NewGuid().ToString();
            //const string extension = ".txt";
            return Path.Combine(sPath, sUniqueName);
        }

        private string QuoteSQLString(string str)
        {
            return str.Replace("\"\"", "\"");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbType.SelectedIndex = 0;
            DecideVisibility();
        }

        private bool ValidateInput()
        {
            StringBuilder sb = new StringBuilder();
            if (cmbType.SelectedItem.ToString() == "Image")
            {
                if (string.IsNullOrEmpty(openFileDialog1.FileName) || openFileDialog1.FileName == "openFileDialog1")
                {
                    sb.Append("No file selected, Please select a file\n");
                }

            }
            if (cmbType.SelectedItem.ToString() == "Text")
            {
                if (string.IsNullOrEmpty(txtgeneric.Text))
                {
                    sb.Append("Please enter the text you need to show in this section\n");
                }
            }
            if (cmbType.SelectedItem.ToString() == "Spacer")
            {
                if (string.IsNullOrEmpty(txtgeneric.Text))
                {
                    sb.Append("Please enter the height of spacer\n");
                }
                try
                {
                    Convert.ToInt32(txtgeneric.Text);

                }
                catch
                {
                    sb.Append("Height of spacer must be numeric\n");
                }

            }
            if (sb != null && !string.IsNullOrEmpty(sb.ToString()))
            {
                MessageBox.Show(sb.ToString(), "Error Adding input", MessageBoxButtons.OKCancel);
                return false;
            }
            else
                return true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ucText uc = new ucText();
            
            uc.Show();
            this.Controls.Add(uc);
        }

        private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            MessageBox.Show(e.RowIndex.ToString());
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            MessageBox.Show(e.RowIndex.ToString());
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
           DataGridViewRow row= dataGridView1.Rows[e.RowIndex];
            if(row!=null && row.Cells["Type"].Value.ToString()=="Text")
            {
                AddText add = new AddText((AdiText)row.Cells["Object"].Value);
                
                    add.ShowDialog();
                    if (add != null && add.Adi!=null)
                    {
                    row.Cells["ImagePath"].Value = add.Adi.style;
                    row.Cells["BgColor"].Value = add.Adi.text;
                    //row.Cells["Spacer Height"].Value = add.Adi;
                    row.Cells["Object"].Value = add.Adi;
                    add.Close();
                    add.Dispose();
                    this.Focus();
                }
            }
        }

        private void btnClone_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow item in dataGridView1.SelectedRows)
            {
                DataGridViewRow clonedRow = (DataGridViewRow)item.Clone();
                for (Int32 index = 0; index < item.Cells.Count; index++)
                {
                    clonedRow.Cells[index].Value = item.Cells[index].Value;
                }
                dataGridView1.Rows.Add(clonedRow);
            }
        }
    }




    //public class AdiImage
    //{
    //    public string imagePath;
    //    public string bgColor;
    //    public string HTML;
    //    public string imageName;
    //    public string imageAlternateText;
    //    public bool isLink;
    //    public string link;
    //    public string target_link;
    //};
  
    //public class AdiSpacer
    //{
    //    public string height;
    //    public string bgColor;
    //    public string HTML;
    //};

    public class Responsive_1X2
    {
        public string bgcolor;
        public string paths;
        public string HTML;
    };

}