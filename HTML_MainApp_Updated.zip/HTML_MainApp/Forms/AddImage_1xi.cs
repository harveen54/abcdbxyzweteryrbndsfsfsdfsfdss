﻿using HTML_MainApp.Classes;
using HTML_MainApp.UserControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HTML_MainApp.Forms
{
    public partial class AddImage_1xi : Form
    {
          public bool IsAdded;
       
        private AdiImage_1xi _adi;

        public AdiImage_1xi Adi
        {
            get { return _adi; }
            set { _adi = value; }
        }

        public AddImage_1xi()
        {
            InitializeComponent();
        }

        public AddImage_1xi(AdiImage_1xi text)
        {
            InitializeComponent();
            InitializeControls(text.elements,text);

            //ucAddText.SetValueOfStyle(text.fontProperties);
            //ucAddText.SetText(text.text);
            //ucAddText.SetAlignmentValues(text.fontProperties);
            //btnAdd.Text = "Update";
          
        }

        public void InitializeControls(int n, AdiImage_1xi text)
        {
            ucImage[] controls = new ucImage[n];

            for (int i = 0; i < n; i++)
            {
                controls[i] = new ucImage();
            }

            int y = 0;
            for (int i = 0; i < n; i++)
            {
                if (i != 0)
                    y += i + 300;

                controls[i].Location = new Point(i, y);
                controls[i].SetImageProperties(text.listAdiText[i]);
                controls[i].SetTdStyleProperties(text.listAdiText[i]);
                controls[i].SetAlignmentValues(text.listAdiText[i]);
                this.panel1.Controls.Add(controls[i]);
            }
            btnAdd.Text = "Update";
            txtNumber.Text = n.ToString();
            txtNumber.Enabled = false;
            btnGo.Enabled = false;
            Adi = text;
            Adi.controls = controls;
        }


        private void btnGo_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtNumber.Text))
            {
                int n = Convert.ToInt32(txtNumber.Text);

                ucImage[] controls = new ucImage[n];
                for (int i = 0; i < n; i++)
                {
                    controls[i] = new ucImage();
             }
                int y = 0;
                for (int i = 0; i < n; i++)
                {
                    if (i != 0)
                        y += i + 300;

                    controls[i].Location = new Point(i, y);
                    this.panel1.Controls.Add(controls[i]);
                }
                Adi = new AdiImage_1xi()
                {
                    controls = controls,
                    elements = n
                };

            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (btnAdd.Text == "Update")
            {

            }
            else
            IsAdded = true;
            int n = Convert.ToInt32(txtNumber.Text);
            int flag = 0;
            AdiImage[] aditext = new AdiImage[n];
            for (int i = 0; i < n; i++)
            {
                var ucAddText = Adi.controls[i];
                Adi.controls[i].ValidateForm();
                if (!ucAddText.HasErrors)
                {
                    var classAdi = new AdiImage();

                   

                    classAdi.style = ucAddText.GetTdStyleProperties();
                    ucAddText.GetImageProperties();
                    classAdi.alignment = ucAddText.GetAlignmentValues();
                    
                    classAdi.alink = ucAddText.Img.alink;
                    classAdi.alternateText = ucAddText.Img.alternateText;
                    classAdi.background_color = ucAddText.Img.background_color;
                    classAdi.bBottom = ucAddText.Img.bBottom;
                    classAdi.bLeft = ucAddText.Img.bLeft;
                    classAdi.borderColor = ucAddText.Img.borderColor;
                    classAdi.bRight = ucAddText.Img.bRight;
                    classAdi.bTop = ucAddText.Img.bTop;
                    classAdi.hAlign = ucAddText.Img.hAlign;
                    classAdi.HTML = ucAddText.Img.HTML;
                    classAdi.imagePath = ucAddText.Img.imagePath;
                    classAdi.isLink = ucAddText.Img.isLink;
                    classAdi.isSet = ucAddText.Img.isSet;
                    classAdi.isUpdated = ucAddText.Img.isUpdated;
                    classAdi.link = ucAddText.Img.link;
                    classAdi.mBottom = ucAddText.Img.mBottom;
                    classAdi.mLeft = ucAddText.Img.mLeft;
                    classAdi.mRight = ucAddText.Img.mRight;
                    classAdi.mTop = ucAddText.Img.mTop;
                    classAdi.Path = ucAddText.Img.Path;
                    classAdi.pBottom = ucAddText.Img.pBottom;
                    classAdi.pLeft = ucAddText.Img.pLeft;
                    classAdi.pRight = ucAddText.Img.pRight;
                    classAdi.pTop = ucAddText.Img.pTop;
                   
                    classAdi.vAlign = ucAddText.Img.vAlign;
                    classAdi.width = ucAddText.Img.width;
                    
                    //if (ucAddText.isLink)
                    //{
                    //    Adi.alink = string.Format(@"<a href=""{0}"" target=""_blank"" >", Adi.link);
                    //}
                    aditext[i] = classAdi;
                    this.Hide();
                }

                else
                {
                    flag = 1;
                }
            }
           
            if (flag == 1)
                MessageBox.Show("Please correct the fields in red");
            else
            {
                Adi.listAdiText = aditext;
            
                this.Hide();
            }

        }
    }
}
