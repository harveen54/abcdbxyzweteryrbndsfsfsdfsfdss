﻿using HTML_MainApp.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HTML_MainApp.Forms
{
    public partial class AddButton : Form
    {
        public AddButton()
        {
            InitializeComponent();
        }

        public AddButton(AdiButton spc)
        {
            InitializeComponent();
            txtLink.Text = spc.link;
            lblFileName.Text = spc.source;
            lblFullPath.Text = spc.fullName;
            btnAdd.Text = "Update";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnUpload_Click(object sender, EventArgs e)
        {

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string fileName = openFileDialog1.FileName;
                lblFileName.Text = openFileDialog1.SafeFileName;
                lblFullPath.Text = openFileDialog1.FileName;
            }
        }

        private AdiButton _button;

        public AdiButton button
        {
            get { return _button; }
            set { _button = value; }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtLink.Text) && !string.IsNullOrEmpty(lblFileName.Text))
            {
                button = new AdiButton();


                button.link = txtLink.Text;
                button.source = lblFileName.Text;

                if (btnAdd.Text == "Add")
                {
                    button.isAdded = true;
                    button.fullName = openFileDialog1.FileName;
                }
                else if (btnAdd.Text == "Update")
                {
                    button.isUpdated = true;
                    button.fullName = lblFullPath.Text;
                } this.Hide();
            }
            else
            {
                MessageBox.Show("Please enter Link and select an image");
            }
        }

        private void btnPreview_Click(object sender, EventArgs e)
        {
            string html = string.Format(@"  <tr><table class=""width100"" width=""640"" align=""center"" valign=""top"" cellpadding=""0"" cellspacing=""0"">

<tr>
                                    <td align=""center"">
                                        <!-- red button starts -->
                                        <table class=""width100"" border=""0"" cellpadding=""0"" cellspacing=""0"" style=""border-collapse:initial;"">
                                            <tbody>
                                                <tr>
                                                    <td align=""center"" valign=""middle"">
                                                        <a href=""{0}""><img src=""{1}"" border=""0"" alt="""" style=""display:block;""></a>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!-- red button closed -->
                                    </td>
                                </tr>
								</table>
								</tr>", txtLink.Text, openFileDialog1.FileName);
            PreviewForm p = new PreviewForm(html);
            p.ShowDialog();
                
        }
    }
}
