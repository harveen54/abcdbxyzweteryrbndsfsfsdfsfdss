﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HTML_MainApp.Forms
{
    public partial class PreviewForm : Form
    {
        public PreviewForm()
        {
            InitializeComponent();
        }
        public PreviewForm(string html)
        {
            InitializeComponent();
            webBrowser1.DocumentText =
    "<html><body>" +html +
    "</body></html>";

           
        }
    }
}
