﻿using HTML_MainApp.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HTML_MainApp.Forms
{
    public partial class AddText : Form
    {
        public bool IsAdded;
        private AdiText _adi;

        public AdiText Adi
        {
            get { return _adi; }
            set { _adi = value; }
        }

        public AddText()
        {
            InitializeComponent();
            
        }

        public AddText(AdiText text)
        {
            InitializeComponent();
            ucAddText.SetValueOfStyle(text.fontProperties);
            ucAddText.SetText(text.text);
            ucAddText.SetAlignmentValues(text.fontProperties);
            btnAdd.Text = "Update";
          
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
             Adi = new AdiText();
             Adi.isSet = false;
             Adi.isUpdated = false;
             ucAddText.ValidateForm();
             if (!ucAddText.HasErrors)
             {

                 Adi.style = ucAddText.GetValueOfStyle();
                 Adi.text = ucAddText.GetText();
                 Adi.alignment = ucAddText.GetAlignmentValues();
                 Adi.fontProperties = ucAddText.FontP;
                 if (btnAdd.Text == "ADD")
                     Adi.isSet = true;
                 else if (btnAdd.Text == "Update")
                     Adi.isUpdated = true;
                 this.Hide();
             }

             else
             {
                 MessageBox.Show("Please correct the fields in red");
             }
        }

        private void btnPreview_Click(object sender, EventArgs e)
        {
            string html = string.Format(@"<tr>
                                    <td >
                                        <table border=""0"" cellpadding=""0"" width=""640"" align=""center"" class=""templateColumns100"" cellspacing=""0"">
                                            <tr>
                                                <td {0}  style=""{1}"">
                                                    <span>
                                                       {2}
													   </span>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>", ucAddText.GetAlignmentValues(), ucAddText.GetValueOfStyle(), ucAddText.GetText());
            PreviewForm p = new PreviewForm(html);
            p.ShowDialog();
        }
    }
}
