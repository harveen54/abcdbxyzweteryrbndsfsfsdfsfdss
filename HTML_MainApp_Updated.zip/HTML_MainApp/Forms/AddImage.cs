﻿using HTML_MainApp.Classes;
using HTML_MainApp.UserControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HTML_MainApp.Forms
{
    public partial class AddImage : Form
    {
        public bool IsAdded;
        private AdiImage _adi;

        public AdiImage Adi
        {
            get { return _adi; }
            set { _adi = value; }
        }
        public AddImage()
        {
            InitializeComponent();
        }
        public AddImage(AdiImage img)
        {
            InitializeComponent();
            brnAdd.Text = "Update";
            ucAddImage.SetAlignmentValues(img);
            ucAddImage.SetImageProperties(img);
            ucAddImage.SetTdStyleProperties(img);
        }

        private void brnAdd_Click(object sender, EventArgs e)
        {
            IsAdded = true;
          //  Adi = new AdiImage();
            ucAddImage.ValidateField();
            if (!ucAddImage.HasErrors)
            {
                ucAddImage.ValidateForm();
                if (!ucAddImage.HasErrors)
                {

                    Adi = ucAddImage.Img;
                    Adi.style = ucAddImage.GetTdStyleProperties();
                    ucAddImage.GetImageProperties();
                    // Adi.alink= 
                    Adi.alignment = ucAddImage.GetAlignmentValues();
                    if (Adi.isLink)
                    {
                        Adi.alink = string.Format(@"<a href=""{0}"" target=""_blank"" >", Adi.link);
                    }
                    else
                        Adi.alink = "";
                    if (brnAdd.Text == "Add")
                        Adi.isSet = true;
                    else if (brnAdd.Text == "Update")
                        Adi.isUpdated = true;
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Please correct the fields marked in Red");
                }
            }

            else
            {
                MessageBox.Show("Please select an Image File First");
            }
        }

        private void btnPreview_Click(object sender, EventArgs e)
        {
            Adi = ucAddImage.Img;
            ucAddImage.GetImageProperties();
            string html = String.Format(@"      <tr>
            <td>
                <table cellpadding=""0"" cellspacing=""0"" border=""0"" width=""100%"">
                    <!-- body part 1 starts -->
                    <tr>
                        <td>
                            <table border=""0"" cellpadding=""0"" cellspacing=""0"" width=""100%"">
                                <tr>
                                    <td align=""center"" valign=""top"" style=""background-color:#{0};"">
                                        <table border=""0"" width=""640"" cellpadding=""0"" cellspacing=""0"" class=""container"" style=""background-color:#{0};"">
                                            <tr>
                                                <td align=""left"" valign=""top"" style=""{2}"" width=""{5}%"">
                                                    <table border=""0"" width=""100%"" cellpadding=""0"" cellspacing=""0"">
                                                        <tr>
                                                            <td {1} >
{6}
                                                                <img class=""resizeImg"" style=""display:block;"" src=""{3}"" alt=""{4}"" >
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
								</table>
                        </td>
                    </tr>
                    <!-- body part 1 closed -->
                </table>

            </td>
        </tr>", Adi.background_color, ucAddImage.GetAlignmentValues(), ucAddImage.GetTdStyleProperties(), Adi.imagePath, Adi.alternateText, Adi.width, Adi.alink);
            PreviewForm p = new PreviewForm(html);
            p.ShowDialog();
        }
    }
}
